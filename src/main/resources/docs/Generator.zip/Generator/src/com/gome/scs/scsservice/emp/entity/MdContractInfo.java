package com.gome.scs.scsservice.emp.entity;

import java.util.Date;

public class MdContractInfo {
    private Integer id;

    private String documentType;

    private String contractCode;

    private String companyCode;

    private String buyorgCode;

    private String suppCode;

    private String classCode;

    private Byte classType;

    private String brandCode;

    private String commodityCode;

    private String tranContractCode;

    private String isTranAdjust;

    private String payTermCode;

    private String payModeCode;

    private String issue;

    private String invoiceType;

    private Date effectStartDate;

    private Date effectEndDate;

    private Date realEndDate;

    private Integer buygrpCode;

    private String area;

    private String region;

    private String remark;

    private String empFormCode;

    private Integer contractSign;

    private String oaAdjustCode;

    private String isVirtualContract;

    private String isProtoContract;

    private String isOneStepVirtual;

    private String empRevokeShopCode;

    private Date imageValidDate;

    private Byte scope;

    private String visitStore;

    private String characterId;

    private Short contractYear;

    private String exchangeFreight;

    private String imperfectionFreight;

    private Float imperfectionRate;

    private String heelPriceFreight;

    private Float heelPriceRate;

    private String collectDelayDeliveryFreight;

    private String isRemoved;

    private String creator;

    private Date createTime;

    private String modifier;

    private Date modifyDate;

    private Date updateTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType == null ? null : documentType.trim();
    }

    public String getContractCode() {
        return contractCode;
    }

    public void setContractCode(String contractCode) {
        this.contractCode = contractCode == null ? null : contractCode.trim();
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode == null ? null : companyCode.trim();
    }

    public String getBuyorgCode() {
        return buyorgCode;
    }

    public void setBuyorgCode(String buyorgCode) {
        this.buyorgCode = buyorgCode == null ? null : buyorgCode.trim();
    }

    public String getSuppCode() {
        return suppCode;
    }

    public void setSuppCode(String suppCode) {
        this.suppCode = suppCode == null ? null : suppCode.trim();
    }

    public String getClassCode() {
        return classCode;
    }

    public void setClassCode(String classCode) {
        this.classCode = classCode == null ? null : classCode.trim();
    }

    public Byte getClassType() {
        return classType;
    }

    public void setClassType(Byte classType) {
        this.classType = classType;
    }

    public String getBrandCode() {
        return brandCode;
    }

    public void setBrandCode(String brandCode) {
        this.brandCode = brandCode == null ? null : brandCode.trim();
    }

    public String getCommodityCode() {
        return commodityCode;
    }

    public void setCommodityCode(String commodityCode) {
        this.commodityCode = commodityCode == null ? null : commodityCode.trim();
    }

    public String getTranContractCode() {
        return tranContractCode;
    }

    public void setTranContractCode(String tranContractCode) {
        this.tranContractCode = tranContractCode == null ? null : tranContractCode.trim();
    }

    public String getIsTranAdjust() {
        return isTranAdjust;
    }

    public void setIsTranAdjust(String isTranAdjust) {
        this.isTranAdjust = isTranAdjust == null ? null : isTranAdjust.trim();
    }

    public String getPayTermCode() {
        return payTermCode;
    }

    public void setPayTermCode(String payTermCode) {
        this.payTermCode = payTermCode == null ? null : payTermCode.trim();
    }

    public String getPayModeCode() {
        return payModeCode;
    }

    public void setPayModeCode(String payModeCode) {
        this.payModeCode = payModeCode == null ? null : payModeCode.trim();
    }

    public String getIssue() {
        return issue;
    }

    public void setIssue(String issue) {
        this.issue = issue == null ? null : issue.trim();
    }

    public String getInvoiceType() {
        return invoiceType;
    }

    public void setInvoiceType(String invoiceType) {
        this.invoiceType = invoiceType == null ? null : invoiceType.trim();
    }

    public Date getEffectStartDate() {
        return effectStartDate;
    }

    public void setEffectStartDate(Date effectStartDate) {
        this.effectStartDate = effectStartDate;
    }

    public Date getEffectEndDate() {
        return effectEndDate;
    }

    public void setEffectEndDate(Date effectEndDate) {
        this.effectEndDate = effectEndDate;
    }

    public Date getRealEndDate() {
        return realEndDate;
    }

    public void setRealEndDate(Date realEndDate) {
        this.realEndDate = realEndDate;
    }

    public Integer getBuygrpCode() {
        return buygrpCode;
    }

    public void setBuygrpCode(Integer buygrpCode) {
        this.buygrpCode = buygrpCode;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area == null ? null : area.trim();
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region == null ? null : region.trim();
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getEmpFormCode() {
        return empFormCode;
    }

    public void setEmpFormCode(String empFormCode) {
        this.empFormCode = empFormCode == null ? null : empFormCode.trim();
    }

    public Integer getContractSign() {
        return contractSign;
    }

    public void setContractSign(Integer contractSign) {
        this.contractSign = contractSign;
    }

    public String getOaAdjustCode() {
        return oaAdjustCode;
    }

    public void setOaAdjustCode(String oaAdjustCode) {
        this.oaAdjustCode = oaAdjustCode == null ? null : oaAdjustCode.trim();
    }

    public String getIsVirtualContract() {
        return isVirtualContract;
    }

    public void setIsVirtualContract(String isVirtualContract) {
        this.isVirtualContract = isVirtualContract == null ? null : isVirtualContract.trim();
    }

    public String getIsProtoContract() {
        return isProtoContract;
    }

    public void setIsProtoContract(String isProtoContract) {
        this.isProtoContract = isProtoContract == null ? null : isProtoContract.trim();
    }

    public String getIsOneStepVirtual() {
        return isOneStepVirtual;
    }

    public void setIsOneStepVirtual(String isOneStepVirtual) {
        this.isOneStepVirtual = isOneStepVirtual == null ? null : isOneStepVirtual.trim();
    }

    public String getEmpRevokeShopCode() {
        return empRevokeShopCode;
    }

    public void setEmpRevokeShopCode(String empRevokeShopCode) {
        this.empRevokeShopCode = empRevokeShopCode == null ? null : empRevokeShopCode.trim();
    }

    public Date getImageValidDate() {
        return imageValidDate;
    }

    public void setImageValidDate(Date imageValidDate) {
        this.imageValidDate = imageValidDate;
    }

    public Byte getScope() {
        return scope;
    }

    public void setScope(Byte scope) {
        this.scope = scope;
    }

    public String getVisitStore() {
        return visitStore;
    }

    public void setVisitStore(String visitStore) {
        this.visitStore = visitStore == null ? null : visitStore.trim();
    }

    public String getCharacterId() {
        return characterId;
    }

    public void setCharacterId(String characterId) {
        this.characterId = characterId == null ? null : characterId.trim();
    }

    public Short getContractYear() {
        return contractYear;
    }

    public void setContractYear(Short contractYear) {
        this.contractYear = contractYear;
    }

    public String getExchangeFreight() {
        return exchangeFreight;
    }

    public void setExchangeFreight(String exchangeFreight) {
        this.exchangeFreight = exchangeFreight == null ? null : exchangeFreight.trim();
    }

    public String getImperfectionFreight() {
        return imperfectionFreight;
    }

    public void setImperfectionFreight(String imperfectionFreight) {
        this.imperfectionFreight = imperfectionFreight == null ? null : imperfectionFreight.trim();
    }

    public Float getImperfectionRate() {
        return imperfectionRate;
    }

    public void setImperfectionRate(Float imperfectionRate) {
        this.imperfectionRate = imperfectionRate;
    }

    public String getHeelPriceFreight() {
        return heelPriceFreight;
    }

    public void setHeelPriceFreight(String heelPriceFreight) {
        this.heelPriceFreight = heelPriceFreight == null ? null : heelPriceFreight.trim();
    }

    public Float getHeelPriceRate() {
        return heelPriceRate;
    }

    public void setHeelPriceRate(Float heelPriceRate) {
        this.heelPriceRate = heelPriceRate;
    }

    public String getCollectDelayDeliveryFreight() {
        return collectDelayDeliveryFreight;
    }

    public void setCollectDelayDeliveryFreight(String collectDelayDeliveryFreight) {
        this.collectDelayDeliveryFreight = collectDelayDeliveryFreight == null ? null : collectDelayDeliveryFreight.trim();
    }

    public String getIsRemoved() {
        return isRemoved;
    }

    public void setIsRemoved(String isRemoved) {
        this.isRemoved = isRemoved == null ? null : isRemoved.trim();
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator == null ? null : creator.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier == null ? null : modifier.trim();
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}