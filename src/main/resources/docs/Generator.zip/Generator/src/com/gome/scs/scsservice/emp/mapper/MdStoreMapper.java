package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdStore;

public interface MdStoreMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdStore record);

    int insertSelective(MdStore record);

    MdStore selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdStore record);

    int updateByPrimaryKey(MdStore record);
}