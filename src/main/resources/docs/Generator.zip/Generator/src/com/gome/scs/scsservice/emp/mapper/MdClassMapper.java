package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdClass;

public interface MdClassMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdClass record);

    int insertSelective(MdClass record);

    MdClass selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdClass record);

    int updateByPrimaryKey(MdClass record);
}