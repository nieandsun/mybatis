package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.SynContractSapLog;

public interface SynContractSapLogMapper {
    int deleteByPrimaryKey(Long id);

    int insert(SynContractSapLog record);

    int insertSelective(SynContractSapLog record);

    SynContractSapLog selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(SynContractSapLog record);

    int updateByPrimaryKey(SynContractSapLog record);
}