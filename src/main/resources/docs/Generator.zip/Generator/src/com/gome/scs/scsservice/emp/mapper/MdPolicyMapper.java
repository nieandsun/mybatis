package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdPolicy;

public interface MdPolicyMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdPolicy record);

    int insertSelective(MdPolicy record);

    MdPolicy selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdPolicy record);

    int updateByPrimaryKey(MdPolicy record);
}