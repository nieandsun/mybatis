package com.gome.scs.scsservice.emp.entity;

import java.util.Date;

public class ScsOaContract {
    private Integer id;

    private String scsCode;

    private String oaCode;

    private String oaFormUrl;

    private String contractCode;

    private String status;

    private String contractImageUploadDate;

    private String createPerson;

    private Date createTime;

    private String updatePerson;

    private Date updateTime;

    private String sendMessageId;

    private String receiveMessageId;

    private String isRemoved;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getScsCode() {
        return scsCode;
    }

    public void setScsCode(String scsCode) {
        this.scsCode = scsCode == null ? null : scsCode.trim();
    }

    public String getOaCode() {
        return oaCode;
    }

    public void setOaCode(String oaCode) {
        this.oaCode = oaCode == null ? null : oaCode.trim();
    }

    public String getOaFormUrl() {
        return oaFormUrl;
    }

    public void setOaFormUrl(String oaFormUrl) {
        this.oaFormUrl = oaFormUrl == null ? null : oaFormUrl.trim();
    }

    public String getContractCode() {
        return contractCode;
    }

    public void setContractCode(String contractCode) {
        this.contractCode = contractCode == null ? null : contractCode.trim();
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    public String getContractImageUploadDate() {
        return contractImageUploadDate;
    }

    public void setContractImageUploadDate(String contractImageUploadDate) {
        this.contractImageUploadDate = contractImageUploadDate == null ? null : contractImageUploadDate.trim();
    }

    public String getCreatePerson() {
        return createPerson;
    }

    public void setCreatePerson(String createPerson) {
        this.createPerson = createPerson == null ? null : createPerson.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdatePerson() {
        return updatePerson;
    }

    public void setUpdatePerson(String updatePerson) {
        this.updatePerson = updatePerson == null ? null : updatePerson.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getSendMessageId() {
        return sendMessageId;
    }

    public void setSendMessageId(String sendMessageId) {
        this.sendMessageId = sendMessageId == null ? null : sendMessageId.trim();
    }

    public String getReceiveMessageId() {
        return receiveMessageId;
    }

    public void setReceiveMessageId(String receiveMessageId) {
        this.receiveMessageId = receiveMessageId == null ? null : receiveMessageId.trim();
    }

    public String getIsRemoved() {
        return isRemoved;
    }

    public void setIsRemoved(String isRemoved) {
        this.isRemoved = isRemoved == null ? null : isRemoved.trim();
    }
}