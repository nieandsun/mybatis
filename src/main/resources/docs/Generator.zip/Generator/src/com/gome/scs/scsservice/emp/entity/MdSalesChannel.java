package com.gome.scs.scsservice.emp.entity;

public class MdSalesChannel {
    private Integer id;

    private String salesChannelCode;

    private String salesChannelName;

    private String isRemoved;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSalesChannelCode() {
        return salesChannelCode;
    }

    public void setSalesChannelCode(String salesChannelCode) {
        this.salesChannelCode = salesChannelCode == null ? null : salesChannelCode.trim();
    }

    public String getSalesChannelName() {
        return salesChannelName;
    }

    public void setSalesChannelName(String salesChannelName) {
        this.salesChannelName = salesChannelName == null ? null : salesChannelName.trim();
    }

    public String getIsRemoved() {
        return isRemoved;
    }

    public void setIsRemoved(String isRemoved) {
        this.isRemoved = isRemoved == null ? null : isRemoved.trim();
    }
}