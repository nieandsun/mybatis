package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdSupp;

public interface MdSuppMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdSupp record);

    int insertSelective(MdSupp record);

    MdSupp selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdSupp record);

    int updateByPrimaryKey(MdSupp record);
}