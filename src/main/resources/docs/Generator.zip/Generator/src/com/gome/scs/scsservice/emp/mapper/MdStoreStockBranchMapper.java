package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdStoreStockBranch;

public interface MdStoreStockBranchMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdStoreStockBranch record);

    int insertSelective(MdStoreStockBranch record);

    MdStoreStockBranch selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdStoreStockBranch record);

    int updateByPrimaryKey(MdStoreStockBranch record);
}