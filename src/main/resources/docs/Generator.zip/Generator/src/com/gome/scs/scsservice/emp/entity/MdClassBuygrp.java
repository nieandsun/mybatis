package com.gome.scs.scsservice.emp.entity;

import java.util.Date;

public class MdClassBuygrp {
    private Integer id;

    private String classCode;

    private String buygrpCode;

    private Date updateTime;

    private String isRemoved;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getClassCode() {
        return classCode;
    }

    public void setClassCode(String classCode) {
        this.classCode = classCode == null ? null : classCode.trim();
    }

    public String getBuygrpCode() {
        return buygrpCode;
    }

    public void setBuygrpCode(String buygrpCode) {
        this.buygrpCode = buygrpCode == null ? null : buygrpCode.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getIsRemoved() {
        return isRemoved;
    }

    public void setIsRemoved(String isRemoved) {
        this.isRemoved = isRemoved == null ? null : isRemoved.trim();
    }
}