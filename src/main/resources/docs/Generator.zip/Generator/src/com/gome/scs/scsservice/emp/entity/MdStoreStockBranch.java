package com.gome.scs.scsservice.emp.entity;

import java.util.Date;

public class MdStoreStockBranch {
    private Integer id;

    private String storeCode;

    private String stockCode;

    private String branchCode;

    private String saleGrpCode;

    private String realPhysicalStoreCode;

    private Date updateTime;

    private String isRemoved;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getStoreCode() {
        return storeCode;
    }

    public void setStoreCode(String storeCode) {
        this.storeCode = storeCode == null ? null : storeCode.trim();
    }

    public String getStockCode() {
        return stockCode;
    }

    public void setStockCode(String stockCode) {
        this.stockCode = stockCode == null ? null : stockCode.trim();
    }

    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode == null ? null : branchCode.trim();
    }

    public String getSaleGrpCode() {
        return saleGrpCode;
    }

    public void setSaleGrpCode(String saleGrpCode) {
        this.saleGrpCode = saleGrpCode == null ? null : saleGrpCode.trim();
    }

    public String getRealPhysicalStoreCode() {
        return realPhysicalStoreCode;
    }

    public void setRealPhysicalStoreCode(String realPhysicalStoreCode) {
        this.realPhysicalStoreCode = realPhysicalStoreCode == null ? null : realPhysicalStoreCode.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getIsRemoved() {
        return isRemoved;
    }

    public void setIsRemoved(String isRemoved) {
        this.isRemoved = isRemoved == null ? null : isRemoved.trim();
    }
}