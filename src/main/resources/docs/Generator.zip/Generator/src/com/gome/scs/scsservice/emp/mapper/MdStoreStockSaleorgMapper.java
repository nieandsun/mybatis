package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdStoreStockSaleorg;

public interface MdStoreStockSaleorgMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdStoreStockSaleorg record);

    int insertSelective(MdStoreStockSaleorg record);

    MdStoreStockSaleorg selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdStoreStockSaleorg record);

    int updateByPrimaryKey(MdStoreStockSaleorg record);
}