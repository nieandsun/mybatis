package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdBusinessModel;

public interface MdBusinessModelMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdBusinessModel record);

    int insertSelective(MdBusinessModel record);

    MdBusinessModel selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdBusinessModel record);

    int updateByPrimaryKey(MdBusinessModel record);
}