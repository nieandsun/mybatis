package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdAgreement;

public interface MdAgreementMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdAgreement record);

    int insertSelective(MdAgreement record);

    MdAgreement selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdAgreement record);

    int updateByPrimaryKey(MdAgreement record);
}