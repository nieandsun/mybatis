package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdInformationRecord;

public interface MdInformationRecordMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdInformationRecord record);

    int insertSelective(MdInformationRecord record);

    MdInformationRecord selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdInformationRecord record);

    int updateByPrimaryKey(MdInformationRecord record);
}