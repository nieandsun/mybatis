package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdSuppBuyorg;

public interface MdSuppBuyorgMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdSuppBuyorg record);

    int insertSelective(MdSuppBuyorg record);

    MdSuppBuyorg selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdSuppBuyorg record);

    int updateByPrimaryKey(MdSuppBuyorg record);
}