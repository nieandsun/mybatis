package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdSuppCompany;

public interface MdSuppCompanyMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdSuppCompany record);

    int insertSelective(MdSuppCompany record);

    MdSuppCompany selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdSuppCompany record);

    int updateByPrimaryKey(MdSuppCompany record);
}