package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdEcCommodityProperty;

public interface MdEcCommodityPropertyMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdEcCommodityProperty record);

    int insertSelective(MdEcCommodityProperty record);

    MdEcCommodityProperty selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdEcCommodityProperty record);

    int updateByPrimaryKey(MdEcCommodityProperty record);
}