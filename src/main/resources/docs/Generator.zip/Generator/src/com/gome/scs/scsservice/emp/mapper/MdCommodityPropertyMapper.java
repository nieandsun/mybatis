package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdCommodityProperty;

public interface MdCommodityPropertyMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdCommodityProperty record);

    int insertSelective(MdCommodityProperty record);

    MdCommodityProperty selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdCommodityProperty record);

    int updateByPrimaryKey(MdCommodityProperty record);
}