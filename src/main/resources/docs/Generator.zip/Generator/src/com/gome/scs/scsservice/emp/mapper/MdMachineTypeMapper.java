package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdMachineType;

public interface MdMachineTypeMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdMachineType record);

    int insertSelective(MdMachineType record);

    MdMachineType selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdMachineType record);

    int updateByPrimaryKey(MdMachineType record);
}