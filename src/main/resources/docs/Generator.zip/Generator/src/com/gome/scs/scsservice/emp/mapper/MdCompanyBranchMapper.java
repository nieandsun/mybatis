package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdCompanyBranch;

public interface MdCompanyBranchMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdCompanyBranch record);

    int insertSelective(MdCompanyBranch record);

    MdCompanyBranch selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdCompanyBranch record);

    int updateByPrimaryKey(MdCompanyBranch record);
}