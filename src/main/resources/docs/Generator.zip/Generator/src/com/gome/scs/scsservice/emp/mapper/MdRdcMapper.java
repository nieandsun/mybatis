package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdRdc;

public interface MdRdcMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdRdc record);

    int insertSelective(MdRdc record);

    MdRdc selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdRdc record);

    int updateByPrimaryKey(MdRdc record);
}