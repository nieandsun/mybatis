package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdPayMode;

public interface MdPayModeMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdPayMode record);

    int insertSelective(MdPayMode record);

    MdPayMode selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdPayMode record);

    int updateByPrimaryKey(MdPayMode record);
}