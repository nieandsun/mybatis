package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdContract;

public interface MdContractMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdContract record);

    int insertSelective(MdContract record);

    MdContract selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdContract record);

    int updateByPrimaryKey(MdContract record);
}