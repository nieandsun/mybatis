package com.gome.scs.scsservice.emp.entity;

public class MdAgreementItem {
    private Integer id;

    private Integer agreementId;

    private String agreementCode;

    private String buyCertCode;

    private String skuCode;

    private String targetNum;

    private String buyOrderNum;

    private String meterUnit;

    private String netPrice;

    private String priceUnit;

    private String buyOrderNetValue;

    private String isRemoved;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getAgreementId() {
        return agreementId;
    }

    public void setAgreementId(Integer agreementId) {
        this.agreementId = agreementId;
    }

    public String getAgreementCode() {
        return agreementCode;
    }

    public void setAgreementCode(String agreementCode) {
        this.agreementCode = agreementCode == null ? null : agreementCode.trim();
    }

    public String getBuyCertCode() {
        return buyCertCode;
    }

    public void setBuyCertCode(String buyCertCode) {
        this.buyCertCode = buyCertCode == null ? null : buyCertCode.trim();
    }

    public String getSkuCode() {
        return skuCode;
    }

    public void setSkuCode(String skuCode) {
        this.skuCode = skuCode == null ? null : skuCode.trim();
    }

    public String getTargetNum() {
        return targetNum;
    }

    public void setTargetNum(String targetNum) {
        this.targetNum = targetNum == null ? null : targetNum.trim();
    }

    public String getBuyOrderNum() {
        return buyOrderNum;
    }

    public void setBuyOrderNum(String buyOrderNum) {
        this.buyOrderNum = buyOrderNum == null ? null : buyOrderNum.trim();
    }

    public String getMeterUnit() {
        return meterUnit;
    }

    public void setMeterUnit(String meterUnit) {
        this.meterUnit = meterUnit == null ? null : meterUnit.trim();
    }

    public String getNetPrice() {
        return netPrice;
    }

    public void setNetPrice(String netPrice) {
        this.netPrice = netPrice == null ? null : netPrice.trim();
    }

    public String getPriceUnit() {
        return priceUnit;
    }

    public void setPriceUnit(String priceUnit) {
        this.priceUnit = priceUnit == null ? null : priceUnit.trim();
    }

    public String getBuyOrderNetValue() {
        return buyOrderNetValue;
    }

    public void setBuyOrderNetValue(String buyOrderNetValue) {
        this.buyOrderNetValue = buyOrderNetValue == null ? null : buyOrderNetValue.trim();
    }

    public String getIsRemoved() {
        return isRemoved;
    }

    public void setIsRemoved(String isRemoved) {
        this.isRemoved = isRemoved == null ? null : isRemoved.trim();
    }
}