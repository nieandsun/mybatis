package com.gome.scs.scsservice.emp.entity;

import java.util.Date;

public class MdSupp {
    private Integer id;

    private String companyCode;

    private String buyorgCode;

    private String suppCode;

    private String suppTypeCode;

    private String suppName1;

    private String suppName2;

    private String suppName3;

    private String suppName4;

    private String suppIndex;

    private String companyAttr;

    private String suppClass;

    private String address1;

    private String province;

    private String address2;

    private String address3;

    private String postcode;

    private String cityCode;

    private String provinceCode;

    private String countryCode;

    private String telephone;

    private String mobile;

    private String fax;

    private String email;

    private String dutyCode;

    private String legalPersom;

    private String companyCharacter;

    private String invoiceLimite;

    private String registeFunds;

    private String bankCountry;

    private String bankNumber;

    private String bankCode;

    private String bankAccount;

    private String bankName;

    private String bankProvince;

    private String bankCity;

    private String bankAddress;

    private String bankBranch;

    private String chargeman;

    private String chargemanTelephone;

    private String operateType;

    private String reinSubject;

    private String prompt;

    private String cashManage;

    private String sortCode;

    private String doubleCheck;

    private String payMode;

    private String orderMoney;

    private String invoiceCheckOnReceive;

    private String invoiceCheckOnServer;

    private String businessType;

    private String tradePartner;

    private String consumer;

    private String fixPriceGroup;

    private String bankAccountowner;

    private Date updateTime;

    private String isRemoved;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode == null ? null : companyCode.trim();
    }

    public String getBuyorgCode() {
        return buyorgCode;
    }

    public void setBuyorgCode(String buyorgCode) {
        this.buyorgCode = buyorgCode == null ? null : buyorgCode.trim();
    }

    public String getSuppCode() {
        return suppCode;
    }

    public void setSuppCode(String suppCode) {
        this.suppCode = suppCode == null ? null : suppCode.trim();
    }

    public String getSuppTypeCode() {
        return suppTypeCode;
    }

    public void setSuppTypeCode(String suppTypeCode) {
        this.suppTypeCode = suppTypeCode == null ? null : suppTypeCode.trim();
    }

    public String getSuppName1() {
        return suppName1;
    }

    public void setSuppName1(String suppName1) {
        this.suppName1 = suppName1 == null ? null : suppName1.trim();
    }

    public String getSuppName2() {
        return suppName2;
    }

    public void setSuppName2(String suppName2) {
        this.suppName2 = suppName2 == null ? null : suppName2.trim();
    }

    public String getSuppName3() {
        return suppName3;
    }

    public void setSuppName3(String suppName3) {
        this.suppName3 = suppName3 == null ? null : suppName3.trim();
    }

    public String getSuppName4() {
        return suppName4;
    }

    public void setSuppName4(String suppName4) {
        this.suppName4 = suppName4 == null ? null : suppName4.trim();
    }

    public String getSuppIndex() {
        return suppIndex;
    }

    public void setSuppIndex(String suppIndex) {
        this.suppIndex = suppIndex == null ? null : suppIndex.trim();
    }

    public String getCompanyAttr() {
        return companyAttr;
    }

    public void setCompanyAttr(String companyAttr) {
        this.companyAttr = companyAttr == null ? null : companyAttr.trim();
    }

    public String getSuppClass() {
        return suppClass;
    }

    public void setSuppClass(String suppClass) {
        this.suppClass = suppClass == null ? null : suppClass.trim();
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1 == null ? null : address1.trim();
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province == null ? null : province.trim();
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2 == null ? null : address2.trim();
    }

    public String getAddress3() {
        return address3;
    }

    public void setAddress3(String address3) {
        this.address3 = address3 == null ? null : address3.trim();
    }

    public String getPostcode() {
        return postcode;
    }

    public void setPostcode(String postcode) {
        this.postcode = postcode == null ? null : postcode.trim();
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode == null ? null : cityCode.trim();
    }

    public String getProvinceCode() {
        return provinceCode;
    }

    public void setProvinceCode(String provinceCode) {
        this.provinceCode = provinceCode == null ? null : provinceCode.trim();
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode == null ? null : countryCode.trim();
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone == null ? null : telephone.trim();
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile == null ? null : mobile.trim();
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax == null ? null : fax.trim();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    public String getDutyCode() {
        return dutyCode;
    }

    public void setDutyCode(String dutyCode) {
        this.dutyCode = dutyCode == null ? null : dutyCode.trim();
    }

    public String getLegalPersom() {
        return legalPersom;
    }

    public void setLegalPersom(String legalPersom) {
        this.legalPersom = legalPersom == null ? null : legalPersom.trim();
    }

    public String getCompanyCharacter() {
        return companyCharacter;
    }

    public void setCompanyCharacter(String companyCharacter) {
        this.companyCharacter = companyCharacter == null ? null : companyCharacter.trim();
    }

    public String getInvoiceLimite() {
        return invoiceLimite;
    }

    public void setInvoiceLimite(String invoiceLimite) {
        this.invoiceLimite = invoiceLimite == null ? null : invoiceLimite.trim();
    }

    public String getRegisteFunds() {
        return registeFunds;
    }

    public void setRegisteFunds(String registeFunds) {
        this.registeFunds = registeFunds == null ? null : registeFunds.trim();
    }

    public String getBankCountry() {
        return bankCountry;
    }

    public void setBankCountry(String bankCountry) {
        this.bankCountry = bankCountry == null ? null : bankCountry.trim();
    }

    public String getBankNumber() {
        return bankNumber;
    }

    public void setBankNumber(String bankNumber) {
        this.bankNumber = bankNumber == null ? null : bankNumber.trim();
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode == null ? null : bankCode.trim();
    }

    public String getBankAccount() {
        return bankAccount;
    }

    public void setBankAccount(String bankAccount) {
        this.bankAccount = bankAccount == null ? null : bankAccount.trim();
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName == null ? null : bankName.trim();
    }

    public String getBankProvince() {
        return bankProvince;
    }

    public void setBankProvince(String bankProvince) {
        this.bankProvince = bankProvince == null ? null : bankProvince.trim();
    }

    public String getBankCity() {
        return bankCity;
    }

    public void setBankCity(String bankCity) {
        this.bankCity = bankCity == null ? null : bankCity.trim();
    }

    public String getBankAddress() {
        return bankAddress;
    }

    public void setBankAddress(String bankAddress) {
        this.bankAddress = bankAddress == null ? null : bankAddress.trim();
    }

    public String getBankBranch() {
        return bankBranch;
    }

    public void setBankBranch(String bankBranch) {
        this.bankBranch = bankBranch == null ? null : bankBranch.trim();
    }

    public String getChargeman() {
        return chargeman;
    }

    public void setChargeman(String chargeman) {
        this.chargeman = chargeman == null ? null : chargeman.trim();
    }

    public String getChargemanTelephone() {
        return chargemanTelephone;
    }

    public void setChargemanTelephone(String chargemanTelephone) {
        this.chargemanTelephone = chargemanTelephone == null ? null : chargemanTelephone.trim();
    }

    public String getOperateType() {
        return operateType;
    }

    public void setOperateType(String operateType) {
        this.operateType = operateType == null ? null : operateType.trim();
    }

    public String getReinSubject() {
        return reinSubject;
    }

    public void setReinSubject(String reinSubject) {
        this.reinSubject = reinSubject == null ? null : reinSubject.trim();
    }

    public String getPrompt() {
        return prompt;
    }

    public void setPrompt(String prompt) {
        this.prompt = prompt == null ? null : prompt.trim();
    }

    public String getCashManage() {
        return cashManage;
    }

    public void setCashManage(String cashManage) {
        this.cashManage = cashManage == null ? null : cashManage.trim();
    }

    public String getSortCode() {
        return sortCode;
    }

    public void setSortCode(String sortCode) {
        this.sortCode = sortCode == null ? null : sortCode.trim();
    }

    public String getDoubleCheck() {
        return doubleCheck;
    }

    public void setDoubleCheck(String doubleCheck) {
        this.doubleCheck = doubleCheck == null ? null : doubleCheck.trim();
    }

    public String getPayMode() {
        return payMode;
    }

    public void setPayMode(String payMode) {
        this.payMode = payMode == null ? null : payMode.trim();
    }

    public String getOrderMoney() {
        return orderMoney;
    }

    public void setOrderMoney(String orderMoney) {
        this.orderMoney = orderMoney == null ? null : orderMoney.trim();
    }

    public String getInvoiceCheckOnReceive() {
        return invoiceCheckOnReceive;
    }

    public void setInvoiceCheckOnReceive(String invoiceCheckOnReceive) {
        this.invoiceCheckOnReceive = invoiceCheckOnReceive == null ? null : invoiceCheckOnReceive.trim();
    }

    public String getInvoiceCheckOnServer() {
        return invoiceCheckOnServer;
    }

    public void setInvoiceCheckOnServer(String invoiceCheckOnServer) {
        this.invoiceCheckOnServer = invoiceCheckOnServer == null ? null : invoiceCheckOnServer.trim();
    }

    public String getBusinessType() {
        return businessType;
    }

    public void setBusinessType(String businessType) {
        this.businessType = businessType == null ? null : businessType.trim();
    }

    public String getTradePartner() {
        return tradePartner;
    }

    public void setTradePartner(String tradePartner) {
        this.tradePartner = tradePartner == null ? null : tradePartner.trim();
    }

    public String getConsumer() {
        return consumer;
    }

    public void setConsumer(String consumer) {
        this.consumer = consumer == null ? null : consumer.trim();
    }

    public String getFixPriceGroup() {
        return fixPriceGroup;
    }

    public void setFixPriceGroup(String fixPriceGroup) {
        this.fixPriceGroup = fixPriceGroup == null ? null : fixPriceGroup.trim();
    }

    public String getBankAccountowner() {
        return bankAccountowner;
    }

    public void setBankAccountowner(String bankAccountowner) {
        this.bankAccountowner = bankAccountowner == null ? null : bankAccountowner.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getIsRemoved() {
        return isRemoved;
    }

    public void setIsRemoved(String isRemoved) {
        this.isRemoved = isRemoved == null ? null : isRemoved.trim();
    }
}