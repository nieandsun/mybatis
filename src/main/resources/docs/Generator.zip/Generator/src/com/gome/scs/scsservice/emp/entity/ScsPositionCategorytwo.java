package com.gome.scs.scsservice.emp.entity;

public class ScsPositionCategorytwo {
    private Long id;

    private String positionCode;

    private String categoryTwo;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPositionCode() {
        return positionCode;
    }

    public void setPositionCode(String positionCode) {
        this.positionCode = positionCode == null ? null : positionCode.trim();
    }

    public String getCategoryTwo() {
        return categoryTwo;
    }

    public void setCategoryTwo(String categoryTwo) {
        this.categoryTwo = categoryTwo == null ? null : categoryTwo.trim();
    }
}