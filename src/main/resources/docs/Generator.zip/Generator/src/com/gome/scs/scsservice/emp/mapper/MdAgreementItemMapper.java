package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdAgreementItem;

public interface MdAgreementItemMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdAgreementItem record);

    int insertSelective(MdAgreementItem record);

    MdAgreementItem selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdAgreementItem record);

    int updateByPrimaryKey(MdAgreementItem record);
}