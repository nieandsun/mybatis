package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdBill;

public interface MdBillMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdBill record);

    int insertSelective(MdBill record);

    MdBill selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdBill record);

    int updateByPrimaryKey(MdBill record);
}