package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.TKeyValue;

public interface TKeyValueMapper {
    int deleteByPrimaryKey(Long id);

    int insert(TKeyValue record);

    int insertSelective(TKeyValue record);

    TKeyValue selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TKeyValue record);

    int updateByPrimaryKey(TKeyValue record);
}