package com.gome.scs.scsservice.emp.entity;

public class MdRdc {
    private Integer id;

    private String rdcCode;

    private String saleDeptCode;

    private String saleGroup;

    private String rdcName;

    private String area;

    private String companyCode;

    private String isRemoved;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getRdcCode() {
        return rdcCode;
    }

    public void setRdcCode(String rdcCode) {
        this.rdcCode = rdcCode == null ? null : rdcCode.trim();
    }

    public String getSaleDeptCode() {
        return saleDeptCode;
    }

    public void setSaleDeptCode(String saleDeptCode) {
        this.saleDeptCode = saleDeptCode == null ? null : saleDeptCode.trim();
    }

    public String getSaleGroup() {
        return saleGroup;
    }

    public void setSaleGroup(String saleGroup) {
        this.saleGroup = saleGroup == null ? null : saleGroup.trim();
    }

    public String getRdcName() {
        return rdcName;
    }

    public void setRdcName(String rdcName) {
        this.rdcName = rdcName == null ? null : rdcName.trim();
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area == null ? null : area.trim();
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode == null ? null : companyCode.trim();
    }

    public String getIsRemoved() {
        return isRemoved;
    }

    public void setIsRemoved(String isRemoved) {
        this.isRemoved = isRemoved == null ? null : isRemoved.trim();
    }
}