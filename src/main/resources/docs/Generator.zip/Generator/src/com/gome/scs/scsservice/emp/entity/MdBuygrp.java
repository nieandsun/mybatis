package com.gome.scs.scsservice.emp.entity;

import java.util.Date;

public class MdBuygrp {
    private Integer id;

    private String buygrpCode;

    private String buygrpName;

    private String companyCode;

    private Date updateTime;

    private String isRemoved;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getBuygrpCode() {
        return buygrpCode;
    }

    public void setBuygrpCode(String buygrpCode) {
        this.buygrpCode = buygrpCode == null ? null : buygrpCode.trim();
    }

    public String getBuygrpName() {
        return buygrpName;
    }

    public void setBuygrpName(String buygrpName) {
        this.buygrpName = buygrpName == null ? null : buygrpName.trim();
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode == null ? null : companyCode.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getIsRemoved() {
        return isRemoved;
    }

    public void setIsRemoved(String isRemoved) {
        this.isRemoved = isRemoved == null ? null : isRemoved.trim();
    }
}