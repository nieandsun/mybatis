package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdBuygrp;

public interface MdBuygrpMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdBuygrp record);

    int insertSelective(MdBuygrp record);

    MdBuygrp selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdBuygrp record);

    int updateByPrimaryKey(MdBuygrp record);
}