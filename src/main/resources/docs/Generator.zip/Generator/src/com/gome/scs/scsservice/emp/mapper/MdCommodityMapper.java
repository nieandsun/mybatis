package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdCommodity;

public interface MdCommodityMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdCommodity record);

    int insertSelective(MdCommodity record);

    MdCommodity selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdCommodity record);

    int updateByPrimaryKey(MdCommodity record);
}