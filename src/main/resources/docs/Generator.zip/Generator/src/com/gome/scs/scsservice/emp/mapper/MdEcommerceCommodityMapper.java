package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdEcommerceCommodity;

public interface MdEcommerceCommodityMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdEcommerceCommodity record);

    int insertSelective(MdEcommerceCommodity record);

    MdEcommerceCommodity selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdEcommerceCommodity record);

    int updateByPrimaryKey(MdEcommerceCommodity record);
}