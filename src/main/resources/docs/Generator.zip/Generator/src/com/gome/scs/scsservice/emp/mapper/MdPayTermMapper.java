package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdPayTerm;

public interface MdPayTermMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdPayTerm record);

    int insertSelective(MdPayTerm record);

    MdPayTerm selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdPayTerm record);

    int updateByPrimaryKey(MdPayTerm record);
}