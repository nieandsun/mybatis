package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdContractCompare;

public interface MdContractCompareMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdContractCompare record);

    int insertSelective(MdContractCompare record);

    MdContractCompare selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdContractCompare record);

    int updateByPrimaryKey(MdContractCompare record);
}