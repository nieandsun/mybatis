package com.gome.scs.scsservice.emp.entity;

import java.util.Date;

public class MdSuppCompany {
    private Integer id;

    private String suppCode;

    private String suppName;

    private String companyCode;

    private String companyName;

    private String operateMethod;

    private String reinSubjectCode;

    private String prompt;

    private String cashManage;

    private String sortCode;

    private String payMode;

    private String approveGroup;

    private String doubleCheck;

    private String platformMerchantCode;

    private Date updateTime;

    private String isRemoved;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSuppCode() {
        return suppCode;
    }

    public void setSuppCode(String suppCode) {
        this.suppCode = suppCode == null ? null : suppCode.trim();
    }

    public String getSuppName() {
        return suppName;
    }

    public void setSuppName(String suppName) {
        this.suppName = suppName == null ? null : suppName.trim();
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode == null ? null : companyCode.trim();
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName == null ? null : companyName.trim();
    }

    public String getOperateMethod() {
        return operateMethod;
    }

    public void setOperateMethod(String operateMethod) {
        this.operateMethod = operateMethod == null ? null : operateMethod.trim();
    }

    public String getReinSubjectCode() {
        return reinSubjectCode;
    }

    public void setReinSubjectCode(String reinSubjectCode) {
        this.reinSubjectCode = reinSubjectCode == null ? null : reinSubjectCode.trim();
    }

    public String getPrompt() {
        return prompt;
    }

    public void setPrompt(String prompt) {
        this.prompt = prompt == null ? null : prompt.trim();
    }

    public String getCashManage() {
        return cashManage;
    }

    public void setCashManage(String cashManage) {
        this.cashManage = cashManage == null ? null : cashManage.trim();
    }

    public String getSortCode() {
        return sortCode;
    }

    public void setSortCode(String sortCode) {
        this.sortCode = sortCode == null ? null : sortCode.trim();
    }

    public String getPayMode() {
        return payMode;
    }

    public void setPayMode(String payMode) {
        this.payMode = payMode == null ? null : payMode.trim();
    }

    public String getApproveGroup() {
        return approveGroup;
    }

    public void setApproveGroup(String approveGroup) {
        this.approveGroup = approveGroup == null ? null : approveGroup.trim();
    }

    public String getDoubleCheck() {
        return doubleCheck;
    }

    public void setDoubleCheck(String doubleCheck) {
        this.doubleCheck = doubleCheck == null ? null : doubleCheck.trim();
    }

    public String getPlatformMerchantCode() {
        return platformMerchantCode;
    }

    public void setPlatformMerchantCode(String platformMerchantCode) {
        this.platformMerchantCode = platformMerchantCode == null ? null : platformMerchantCode.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getIsRemoved() {
        return isRemoved;
    }

    public void setIsRemoved(String isRemoved) {
        this.isRemoved = isRemoved == null ? null : isRemoved.trim();
    }
}