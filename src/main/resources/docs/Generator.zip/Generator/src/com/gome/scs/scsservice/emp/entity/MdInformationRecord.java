package com.gome.scs.scsservice.emp.entity;

import java.math.BigDecimal;
import java.util.Date;

public class MdInformationRecord {
    private Integer id;

    private String application;

    private String conditionType;

    private String suppTypeCode;

    private String skuCode;

    private String buyorgCode;

    private String buyRecordType;

    private Date conditionEffectEndDate;

    private Date conditionEffectStartDate;

    private String conditionRecordCode;

    private String conditionCode;

    private String conditionCalculateType;

    private BigDecimal price;

    private String rateType;

    private String approveStatus;

    private String contractCode;

    private String isRemoved;

    private String removedMark;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getApplication() {
        return application;
    }

    public void setApplication(String application) {
        this.application = application == null ? null : application.trim();
    }

    public String getConditionType() {
        return conditionType;
    }

    public void setConditionType(String conditionType) {
        this.conditionType = conditionType == null ? null : conditionType.trim();
    }

    public String getSuppTypeCode() {
        return suppTypeCode;
    }

    public void setSuppTypeCode(String suppTypeCode) {
        this.suppTypeCode = suppTypeCode == null ? null : suppTypeCode.trim();
    }

    public String getSkuCode() {
        return skuCode;
    }

    public void setSkuCode(String skuCode) {
        this.skuCode = skuCode == null ? null : skuCode.trim();
    }

    public String getBuyorgCode() {
        return buyorgCode;
    }

    public void setBuyorgCode(String buyorgCode) {
        this.buyorgCode = buyorgCode == null ? null : buyorgCode.trim();
    }

    public String getBuyRecordType() {
        return buyRecordType;
    }

    public void setBuyRecordType(String buyRecordType) {
        this.buyRecordType = buyRecordType == null ? null : buyRecordType.trim();
    }

    public Date getConditionEffectEndDate() {
        return conditionEffectEndDate;
    }

    public void setConditionEffectEndDate(Date conditionEffectEndDate) {
        this.conditionEffectEndDate = conditionEffectEndDate;
    }

    public Date getConditionEffectStartDate() {
        return conditionEffectStartDate;
    }

    public void setConditionEffectStartDate(Date conditionEffectStartDate) {
        this.conditionEffectStartDate = conditionEffectStartDate;
    }

    public String getConditionRecordCode() {
        return conditionRecordCode;
    }

    public void setConditionRecordCode(String conditionRecordCode) {
        this.conditionRecordCode = conditionRecordCode == null ? null : conditionRecordCode.trim();
    }

    public String getConditionCode() {
        return conditionCode;
    }

    public void setConditionCode(String conditionCode) {
        this.conditionCode = conditionCode == null ? null : conditionCode.trim();
    }

    public String getConditionCalculateType() {
        return conditionCalculateType;
    }

    public void setConditionCalculateType(String conditionCalculateType) {
        this.conditionCalculateType = conditionCalculateType == null ? null : conditionCalculateType.trim();
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public String getRateType() {
        return rateType;
    }

    public void setRateType(String rateType) {
        this.rateType = rateType == null ? null : rateType.trim();
    }

    public String getApproveStatus() {
        return approveStatus;
    }

    public void setApproveStatus(String approveStatus) {
        this.approveStatus = approveStatus == null ? null : approveStatus.trim();
    }

    public String getContractCode() {
        return contractCode;
    }

    public void setContractCode(String contractCode) {
        this.contractCode = contractCode == null ? null : contractCode.trim();
    }

    public String getIsRemoved() {
        return isRemoved;
    }

    public void setIsRemoved(String isRemoved) {
        this.isRemoved = isRemoved == null ? null : isRemoved.trim();
    }

    public String getRemovedMark() {
        return removedMark;
    }

    public void setRemovedMark(String removedMark) {
        this.removedMark = removedMark == null ? null : removedMark.trim();
    }
}