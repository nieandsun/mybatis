package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.ScsOaContract;

public interface ScsOaContractMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(ScsOaContract record);

    int insertSelective(ScsOaContract record);

    ScsOaContract selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(ScsOaContract record);

    int updateByPrimaryKey(ScsOaContract record);
}