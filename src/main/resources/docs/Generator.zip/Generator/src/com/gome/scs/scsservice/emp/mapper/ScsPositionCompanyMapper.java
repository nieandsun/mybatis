package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.ScsPositionCompany;

public interface ScsPositionCompanyMapper {
    int deleteByPrimaryKey(Long id);

    int insert(ScsPositionCompany record);

    int insertSelective(ScsPositionCompany record);

    ScsPositionCompany selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(ScsPositionCompany record);

    int updateByPrimaryKey(ScsPositionCompany record);
}