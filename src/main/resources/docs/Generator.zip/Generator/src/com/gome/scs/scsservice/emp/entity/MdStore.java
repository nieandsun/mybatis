package com.gome.scs.scsservice.emp.entity;

public class MdStore {
    private Integer id;

    private String storeCode;

    private String storeDesc;

    private String storeType;

    private String storeTypeDesc;

    private String buyorgCode;

    private String saleOrgCode;

    private String companyCode;

    private String companyAttr;

    private String companyAttrDesc;

    private String isRemoved;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getStoreCode() {
        return storeCode;
    }

    public void setStoreCode(String storeCode) {
        this.storeCode = storeCode == null ? null : storeCode.trim();
    }

    public String getStoreDesc() {
        return storeDesc;
    }

    public void setStoreDesc(String storeDesc) {
        this.storeDesc = storeDesc == null ? null : storeDesc.trim();
    }

    public String getStoreType() {
        return storeType;
    }

    public void setStoreType(String storeType) {
        this.storeType = storeType == null ? null : storeType.trim();
    }

    public String getStoreTypeDesc() {
        return storeTypeDesc;
    }

    public void setStoreTypeDesc(String storeTypeDesc) {
        this.storeTypeDesc = storeTypeDesc == null ? null : storeTypeDesc.trim();
    }

    public String getBuyorgCode() {
        return buyorgCode;
    }

    public void setBuyorgCode(String buyorgCode) {
        this.buyorgCode = buyorgCode == null ? null : buyorgCode.trim();
    }

    public String getSaleOrgCode() {
        return saleOrgCode;
    }

    public void setSaleOrgCode(String saleOrgCode) {
        this.saleOrgCode = saleOrgCode == null ? null : saleOrgCode.trim();
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode == null ? null : companyCode.trim();
    }

    public String getCompanyAttr() {
        return companyAttr;
    }

    public void setCompanyAttr(String companyAttr) {
        this.companyAttr = companyAttr == null ? null : companyAttr.trim();
    }

    public String getCompanyAttrDesc() {
        return companyAttrDesc;
    }

    public void setCompanyAttrDesc(String companyAttrDesc) {
        this.companyAttrDesc = companyAttrDesc == null ? null : companyAttrDesc.trim();
    }

    public String getIsRemoved() {
        return isRemoved;
    }

    public void setIsRemoved(String isRemoved) {
        this.isRemoved = isRemoved == null ? null : isRemoved.trim();
    }
}