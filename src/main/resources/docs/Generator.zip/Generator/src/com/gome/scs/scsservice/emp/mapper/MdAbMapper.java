package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdAb;

public interface MdAbMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdAb record);

    int insertSelective(MdAb record);

    MdAb selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdAb record);

    int updateByPrimaryKey(MdAb record);
}