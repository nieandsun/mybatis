package com.gome.scs.scsservice.emp.entity;

import java.util.Date;

public class MdBrand {
    private Integer id;

    private String brandCode;

    private String brandName;

    private String brandNameEn;

    private String brandType;

    private String searchAlif;

    private String brandSearchDescribe;

    private Date updateTime;

    private String isRemoved;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getBrandCode() {
        return brandCode;
    }

    public void setBrandCode(String brandCode) {
        this.brandCode = brandCode == null ? null : brandCode.trim();
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName == null ? null : brandName.trim();
    }

    public String getBrandNameEn() {
        return brandNameEn;
    }

    public void setBrandNameEn(String brandNameEn) {
        this.brandNameEn = brandNameEn == null ? null : brandNameEn.trim();
    }

    public String getBrandType() {
        return brandType;
    }

    public void setBrandType(String brandType) {
        this.brandType = brandType == null ? null : brandType.trim();
    }

    public String getSearchAlif() {
        return searchAlif;
    }

    public void setSearchAlif(String searchAlif) {
        this.searchAlif = searchAlif == null ? null : searchAlif.trim();
    }

    public String getBrandSearchDescribe() {
        return brandSearchDescribe;
    }

    public void setBrandSearchDescribe(String brandSearchDescribe) {
        this.brandSearchDescribe = brandSearchDescribe == null ? null : brandSearchDescribe.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getIsRemoved() {
        return isRemoved;
    }

    public void setIsRemoved(String isRemoved) {
        this.isRemoved = isRemoved == null ? null : isRemoved.trim();
    }
}