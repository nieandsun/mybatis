package com.gome.scs.scsservice.emp.entity;

public class TAcGomeUserlog {
    private Long id;

    private String usercode;

    private String username;

    private String adAccount;

    private String adAccountPwd;

    private String appAccount;

    private String appAccountPwd;

    private String companyCode;

    private String companyName;

    private String mobile;

    private String email;

    private String status;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsercode() {
        return usercode;
    }

    public void setUsercode(String usercode) {
        this.usercode = usercode == null ? null : usercode.trim();
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username == null ? null : username.trim();
    }

    public String getAdAccount() {
        return adAccount;
    }

    public void setAdAccount(String adAccount) {
        this.adAccount = adAccount == null ? null : adAccount.trim();
    }

    public String getAdAccountPwd() {
        return adAccountPwd;
    }

    public void setAdAccountPwd(String adAccountPwd) {
        this.adAccountPwd = adAccountPwd == null ? null : adAccountPwd.trim();
    }

    public String getAppAccount() {
        return appAccount;
    }

    public void setAppAccount(String appAccount) {
        this.appAccount = appAccount == null ? null : appAccount.trim();
    }

    public String getAppAccountPwd() {
        return appAccountPwd;
    }

    public void setAppAccountPwd(String appAccountPwd) {
        this.appAccountPwd = appAccountPwd == null ? null : appAccountPwd.trim();
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode == null ? null : companyCode.trim();
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName == null ? null : companyName.trim();
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile == null ? null : mobile.trim();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }
}