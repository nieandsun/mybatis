package com.gome.scs.scsservice.emp.entity;

public class MdCommodity {
    private Integer id;

    private String commodityCode;

    private String commodityName;

    private String commodityType;

    private String brandCode;

    private String classCode;

    private String originPlace;

    private String unit;

    private String weight;

    private String eanCode;

    private String taxType;

    private String length;

    private String wide;

    private String high;

    private String classOne;

    private String classTwo;

    private String classThree;

    private String commodityGroup;

    private String stackingLevel;

    private String sellingPoint;

    private String commodityShape;

    private String warrantyUpperLimit;

    private String warrantyLowerLimit;

    private String abcMark;

    private String commodityStatus;

    private String produceType;

    private String series;

    private String isRemoved;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCommodityCode() {
        return commodityCode;
    }

    public void setCommodityCode(String commodityCode) {
        this.commodityCode = commodityCode == null ? null : commodityCode.trim();
    }

    public String getCommodityName() {
        return commodityName;
    }

    public void setCommodityName(String commodityName) {
        this.commodityName = commodityName == null ? null : commodityName.trim();
    }

    public String getCommodityType() {
        return commodityType;
    }

    public void setCommodityType(String commodityType) {
        this.commodityType = commodityType == null ? null : commodityType.trim();
    }

    public String getBrandCode() {
        return brandCode;
    }

    public void setBrandCode(String brandCode) {
        this.brandCode = brandCode == null ? null : brandCode.trim();
    }

    public String getClassCode() {
        return classCode;
    }

    public void setClassCode(String classCode) {
        this.classCode = classCode == null ? null : classCode.trim();
    }

    public String getOriginPlace() {
        return originPlace;
    }

    public void setOriginPlace(String originPlace) {
        this.originPlace = originPlace == null ? null : originPlace.trim();
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit == null ? null : unit.trim();
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight == null ? null : weight.trim();
    }

    public String getEanCode() {
        return eanCode;
    }

    public void setEanCode(String eanCode) {
        this.eanCode = eanCode == null ? null : eanCode.trim();
    }

    public String getTaxType() {
        return taxType;
    }

    public void setTaxType(String taxType) {
        this.taxType = taxType == null ? null : taxType.trim();
    }

    public String getLength() {
        return length;
    }

    public void setLength(String length) {
        this.length = length == null ? null : length.trim();
    }

    public String getWide() {
        return wide;
    }

    public void setWide(String wide) {
        this.wide = wide == null ? null : wide.trim();
    }

    public String getHigh() {
        return high;
    }

    public void setHigh(String high) {
        this.high = high == null ? null : high.trim();
    }

    public String getClassOne() {
        return classOne;
    }

    public void setClassOne(String classOne) {
        this.classOne = classOne == null ? null : classOne.trim();
    }

    public String getClassTwo() {
        return classTwo;
    }

    public void setClassTwo(String classTwo) {
        this.classTwo = classTwo == null ? null : classTwo.trim();
    }

    public String getClassThree() {
        return classThree;
    }

    public void setClassThree(String classThree) {
        this.classThree = classThree == null ? null : classThree.trim();
    }

    public String getCommodityGroup() {
        return commodityGroup;
    }

    public void setCommodityGroup(String commodityGroup) {
        this.commodityGroup = commodityGroup == null ? null : commodityGroup.trim();
    }

    public String getStackingLevel() {
        return stackingLevel;
    }

    public void setStackingLevel(String stackingLevel) {
        this.stackingLevel = stackingLevel == null ? null : stackingLevel.trim();
    }

    public String getSellingPoint() {
        return sellingPoint;
    }

    public void setSellingPoint(String sellingPoint) {
        this.sellingPoint = sellingPoint == null ? null : sellingPoint.trim();
    }

    public String getCommodityShape() {
        return commodityShape;
    }

    public void setCommodityShape(String commodityShape) {
        this.commodityShape = commodityShape == null ? null : commodityShape.trim();
    }

    public String getWarrantyUpperLimit() {
        return warrantyUpperLimit;
    }

    public void setWarrantyUpperLimit(String warrantyUpperLimit) {
        this.warrantyUpperLimit = warrantyUpperLimit == null ? null : warrantyUpperLimit.trim();
    }

    public String getWarrantyLowerLimit() {
        return warrantyLowerLimit;
    }

    public void setWarrantyLowerLimit(String warrantyLowerLimit) {
        this.warrantyLowerLimit = warrantyLowerLimit == null ? null : warrantyLowerLimit.trim();
    }

    public String getAbcMark() {
        return abcMark;
    }

    public void setAbcMark(String abcMark) {
        this.abcMark = abcMark == null ? null : abcMark.trim();
    }

    public String getCommodityStatus() {
        return commodityStatus;
    }

    public void setCommodityStatus(String commodityStatus) {
        this.commodityStatus = commodityStatus == null ? null : commodityStatus.trim();
    }

    public String getProduceType() {
        return produceType;
    }

    public void setProduceType(String produceType) {
        this.produceType = produceType == null ? null : produceType.trim();
    }

    public String getSeries() {
        return series;
    }

    public void setSeries(String series) {
        this.series = series == null ? null : series.trim();
    }

    public String getIsRemoved() {
        return isRemoved;
    }

    public void setIsRemoved(String isRemoved) {
        this.isRemoved = isRemoved == null ? null : isRemoved.trim();
    }
}