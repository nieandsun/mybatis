package com.gome.scs.scsservice.emp.entity;

import java.util.Date;

public class MdPolicy {
    private Integer id;

    private String groupName;

    private String policyCode;

    private String policyName;

    private String earnCode;

    private String earnName;

    private String unit;

    private String isSameBrandClass;

    private String hasLevel;

    private String levelCalType;

    private String isDelete;

    private String isInProtocol;

    private String connContract;

    private String connProtocol;

    private String connConfirmation;

    private String connOrder;

    private String connProtocolEx;

    private Date updateTime;

    private String isRemoved;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName == null ? null : groupName.trim();
    }

    public String getPolicyCode() {
        return policyCode;
    }

    public void setPolicyCode(String policyCode) {
        this.policyCode = policyCode == null ? null : policyCode.trim();
    }

    public String getPolicyName() {
        return policyName;
    }

    public void setPolicyName(String policyName) {
        this.policyName = policyName == null ? null : policyName.trim();
    }

    public String getEarnCode() {
        return earnCode;
    }

    public void setEarnCode(String earnCode) {
        this.earnCode = earnCode == null ? null : earnCode.trim();
    }

    public String getEarnName() {
        return earnName;
    }

    public void setEarnName(String earnName) {
        this.earnName = earnName == null ? null : earnName.trim();
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit == null ? null : unit.trim();
    }

    public String getIsSameBrandClass() {
        return isSameBrandClass;
    }

    public void setIsSameBrandClass(String isSameBrandClass) {
        this.isSameBrandClass = isSameBrandClass == null ? null : isSameBrandClass.trim();
    }

    public String getHasLevel() {
        return hasLevel;
    }

    public void setHasLevel(String hasLevel) {
        this.hasLevel = hasLevel == null ? null : hasLevel.trim();
    }

    public String getLevelCalType() {
        return levelCalType;
    }

    public void setLevelCalType(String levelCalType) {
        this.levelCalType = levelCalType == null ? null : levelCalType.trim();
    }

    public String getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(String isDelete) {
        this.isDelete = isDelete == null ? null : isDelete.trim();
    }

    public String getIsInProtocol() {
        return isInProtocol;
    }

    public void setIsInProtocol(String isInProtocol) {
        this.isInProtocol = isInProtocol == null ? null : isInProtocol.trim();
    }

    public String getConnContract() {
        return connContract;
    }

    public void setConnContract(String connContract) {
        this.connContract = connContract == null ? null : connContract.trim();
    }

    public String getConnProtocol() {
        return connProtocol;
    }

    public void setConnProtocol(String connProtocol) {
        this.connProtocol = connProtocol == null ? null : connProtocol.trim();
    }

    public String getConnConfirmation() {
        return connConfirmation;
    }

    public void setConnConfirmation(String connConfirmation) {
        this.connConfirmation = connConfirmation == null ? null : connConfirmation.trim();
    }

    public String getConnOrder() {
        return connOrder;
    }

    public void setConnOrder(String connOrder) {
        this.connOrder = connOrder == null ? null : connOrder.trim();
    }

    public String getConnProtocolEx() {
        return connProtocolEx;
    }

    public void setConnProtocolEx(String connProtocolEx) {
        this.connProtocolEx = connProtocolEx == null ? null : connProtocolEx.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getIsRemoved() {
        return isRemoved;
    }

    public void setIsRemoved(String isRemoved) {
        this.isRemoved = isRemoved == null ? null : isRemoved.trim();
    }
}