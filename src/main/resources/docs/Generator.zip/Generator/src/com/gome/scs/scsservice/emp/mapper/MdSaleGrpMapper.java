package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdSaleGrp;

public interface MdSaleGrpMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdSaleGrp record);

    int insertSelective(MdSaleGrp record);

    MdSaleGrp selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdSaleGrp record);

    int updateByPrimaryKey(MdSaleGrp record);
}