package com.gome.scs.scsservice.emp.entity;

import java.util.Date;

public class MdSuppBuyorg {
    private Integer id;

    private String invoiceCheckOnReceive;

    private String invoiceCheckOnServer;

    private String fixPriceGroup;

    private String orderMoney;

    private String buyorg;

    private String buyorgName;

    private String suppCode;

    private String suppName;

    private String prompt;

    private Date updateTime;

    private String isRemoved;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getInvoiceCheckOnReceive() {
        return invoiceCheckOnReceive;
    }

    public void setInvoiceCheckOnReceive(String invoiceCheckOnReceive) {
        this.invoiceCheckOnReceive = invoiceCheckOnReceive == null ? null : invoiceCheckOnReceive.trim();
    }

    public String getInvoiceCheckOnServer() {
        return invoiceCheckOnServer;
    }

    public void setInvoiceCheckOnServer(String invoiceCheckOnServer) {
        this.invoiceCheckOnServer = invoiceCheckOnServer == null ? null : invoiceCheckOnServer.trim();
    }

    public String getFixPriceGroup() {
        return fixPriceGroup;
    }

    public void setFixPriceGroup(String fixPriceGroup) {
        this.fixPriceGroup = fixPriceGroup == null ? null : fixPriceGroup.trim();
    }

    public String getOrderMoney() {
        return orderMoney;
    }

    public void setOrderMoney(String orderMoney) {
        this.orderMoney = orderMoney == null ? null : orderMoney.trim();
    }

    public String getBuyorg() {
        return buyorg;
    }

    public void setBuyorg(String buyorg) {
        this.buyorg = buyorg == null ? null : buyorg.trim();
    }

    public String getBuyorgName() {
        return buyorgName;
    }

    public void setBuyorgName(String buyorgName) {
        this.buyorgName = buyorgName == null ? null : buyorgName.trim();
    }

    public String getSuppCode() {
        return suppCode;
    }

    public void setSuppCode(String suppCode) {
        this.suppCode = suppCode == null ? null : suppCode.trim();
    }

    public String getSuppName() {
        return suppName;
    }

    public void setSuppName(String suppName) {
        this.suppName = suppName == null ? null : suppName.trim();
    }

    public String getPrompt() {
        return prompt;
    }

    public void setPrompt(String prompt) {
        this.prompt = prompt == null ? null : prompt.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getIsRemoved() {
        return isRemoved;
    }

    public void setIsRemoved(String isRemoved) {
        this.isRemoved = isRemoved == null ? null : isRemoved.trim();
    }
}