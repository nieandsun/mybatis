package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.TAcGomeUserlog;

public interface TAcGomeUserlogMapper {
    int deleteByPrimaryKey(Long id);

    int insert(TAcGomeUserlog record);

    int insertSelective(TAcGomeUserlog record);

    TAcGomeUserlog selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TAcGomeUserlog record);

    int updateByPrimaryKey(TAcGomeUserlog record);
}