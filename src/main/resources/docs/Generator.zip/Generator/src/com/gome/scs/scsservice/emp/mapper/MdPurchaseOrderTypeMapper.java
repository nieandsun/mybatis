package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdPurchaseOrderType;

public interface MdPurchaseOrderTypeMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdPurchaseOrderType record);

    int insertSelective(MdPurchaseOrderType record);

    MdPurchaseOrderType selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdPurchaseOrderType record);

    int updateByPrimaryKey(MdPurchaseOrderType record);
}