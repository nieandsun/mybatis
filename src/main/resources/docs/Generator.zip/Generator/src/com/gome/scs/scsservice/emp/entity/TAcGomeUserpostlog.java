package com.gome.scs.scsservice.emp.entity;

import java.util.Date;

public class TAcGomeUserpostlog {
    private Long id;

    private Long userid;

    private String primaryType;

    private String headquatersCode;

    private String headquatersName;

    private String regionCode;

    private String regionName;

    private String firstSubsectionCode;

    private String firstSubsectionName;

    private String secondSubsectionCode;

    private String secondSubsectionName;

    private String storeCode;

    private String storeName;

    private String deptCode;

    private String deptName;

    private String positionCode;

    private String positionDesc;

    private Date startdate;

    private Date enddate;

    private String layer;

    private String layerDetail;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserid() {
        return userid;
    }

    public void setUserid(Long userid) {
        this.userid = userid;
    }

    public String getPrimaryType() {
        return primaryType;
    }

    public void setPrimaryType(String primaryType) {
        this.primaryType = primaryType == null ? null : primaryType.trim();
    }

    public String getHeadquatersCode() {
        return headquatersCode;
    }

    public void setHeadquatersCode(String headquatersCode) {
        this.headquatersCode = headquatersCode == null ? null : headquatersCode.trim();
    }

    public String getHeadquatersName() {
        return headquatersName;
    }

    public void setHeadquatersName(String headquatersName) {
        this.headquatersName = headquatersName == null ? null : headquatersName.trim();
    }

    public String getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode == null ? null : regionCode.trim();
    }

    public String getRegionName() {
        return regionName;
    }

    public void setRegionName(String regionName) {
        this.regionName = regionName == null ? null : regionName.trim();
    }

    public String getFirstSubsectionCode() {
        return firstSubsectionCode;
    }

    public void setFirstSubsectionCode(String firstSubsectionCode) {
        this.firstSubsectionCode = firstSubsectionCode == null ? null : firstSubsectionCode.trim();
    }

    public String getFirstSubsectionName() {
        return firstSubsectionName;
    }

    public void setFirstSubsectionName(String firstSubsectionName) {
        this.firstSubsectionName = firstSubsectionName == null ? null : firstSubsectionName.trim();
    }

    public String getSecondSubsectionCode() {
        return secondSubsectionCode;
    }

    public void setSecondSubsectionCode(String secondSubsectionCode) {
        this.secondSubsectionCode = secondSubsectionCode == null ? null : secondSubsectionCode.trim();
    }

    public String getSecondSubsectionName() {
        return secondSubsectionName;
    }

    public void setSecondSubsectionName(String secondSubsectionName) {
        this.secondSubsectionName = secondSubsectionName == null ? null : secondSubsectionName.trim();
    }

    public String getStoreCode() {
        return storeCode;
    }

    public void setStoreCode(String storeCode) {
        this.storeCode = storeCode == null ? null : storeCode.trim();
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName == null ? null : storeName.trim();
    }

    public String getDeptCode() {
        return deptCode;
    }

    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode == null ? null : deptCode.trim();
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName == null ? null : deptName.trim();
    }

    public String getPositionCode() {
        return positionCode;
    }

    public void setPositionCode(String positionCode) {
        this.positionCode = positionCode == null ? null : positionCode.trim();
    }

    public String getPositionDesc() {
        return positionDesc;
    }

    public void setPositionDesc(String positionDesc) {
        this.positionDesc = positionDesc == null ? null : positionDesc.trim();
    }

    public Date getStartdate() {
        return startdate;
    }

    public void setStartdate(Date startdate) {
        this.startdate = startdate;
    }

    public Date getEnddate() {
        return enddate;
    }

    public void setEnddate(Date enddate) {
        this.enddate = enddate;
    }

    public String getLayer() {
        return layer;
    }

    public void setLayer(String layer) {
        this.layer = layer == null ? null : layer.trim();
    }

    public String getLayerDetail() {
        return layerDetail;
    }

    public void setLayerDetail(String layerDetail) {
        this.layerDetail = layerDetail == null ? null : layerDetail.trim();
    }
}