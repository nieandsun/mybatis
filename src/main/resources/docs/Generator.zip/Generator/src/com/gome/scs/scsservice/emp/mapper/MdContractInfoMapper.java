package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdContractInfo;

public interface MdContractInfoMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdContractInfo record);

    int insertSelective(MdContractInfo record);

    MdContractInfo selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdContractInfo record);

    int updateByPrimaryKey(MdContractInfo record);
}