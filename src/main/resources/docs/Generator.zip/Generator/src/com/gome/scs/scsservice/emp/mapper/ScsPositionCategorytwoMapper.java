package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.ScsPositionCategorytwo;

public interface ScsPositionCategorytwoMapper {
    int deleteByPrimaryKey(Long id);

    int insert(ScsPositionCategorytwo record);

    int insertSelective(ScsPositionCategorytwo record);

    ScsPositionCategorytwo selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(ScsPositionCategorytwo record);

    int updateByPrimaryKey(ScsPositionCategorytwo record);
}