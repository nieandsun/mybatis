package com.gome.scs.scsservice.emp.entity;

import java.util.Date;

public class MdBuyorg {
    private Integer id;

    private String buyorgCode;

    private String buyorgName;

    private String companyCode;

    private Date updateTime;

    private String isRemoved;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getBuyorgCode() {
        return buyorgCode;
    }

    public void setBuyorgCode(String buyorgCode) {
        this.buyorgCode = buyorgCode == null ? null : buyorgCode.trim();
    }

    public String getBuyorgName() {
        return buyorgName;
    }

    public void setBuyorgName(String buyorgName) {
        this.buyorgName = buyorgName == null ? null : buyorgName.trim();
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode == null ? null : companyCode.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getIsRemoved() {
        return isRemoved;
    }

    public void setIsRemoved(String isRemoved) {
        this.isRemoved = isRemoved == null ? null : isRemoved.trim();
    }
}