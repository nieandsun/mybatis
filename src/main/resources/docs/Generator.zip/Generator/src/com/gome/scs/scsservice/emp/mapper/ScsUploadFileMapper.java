package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.ScsUploadFile;

public interface ScsUploadFileMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(ScsUploadFile record);

    int insertSelective(ScsUploadFile record);

    ScsUploadFile selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(ScsUploadFile record);

    int updateByPrimaryKey(ScsUploadFile record);
}