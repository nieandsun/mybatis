package com.gome.scs.scsservice.emp.entity;

import java.util.Date;

public class MdClass {
    private Integer id;

    private String classCode;

    private String className;

    private String classType;

    private String parentClassCode;

    private String isLeaf;

    private String divisionCode;

    private String divisionName;

    private String businessCenter;

    private String productAttr;

    private String fittingAttr;

    private String warrantyProduct;

    private Date updateTime;

    private String isRemoved;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getClassCode() {
        return classCode;
    }

    public void setClassCode(String classCode) {
        this.classCode = classCode == null ? null : classCode.trim();
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className == null ? null : className.trim();
    }

    public String getClassType() {
        return classType;
    }

    public void setClassType(String classType) {
        this.classType = classType == null ? null : classType.trim();
    }

    public String getParentClassCode() {
        return parentClassCode;
    }

    public void setParentClassCode(String parentClassCode) {
        this.parentClassCode = parentClassCode == null ? null : parentClassCode.trim();
    }

    public String getIsLeaf() {
        return isLeaf;
    }

    public void setIsLeaf(String isLeaf) {
        this.isLeaf = isLeaf == null ? null : isLeaf.trim();
    }

    public String getDivisionCode() {
        return divisionCode;
    }

    public void setDivisionCode(String divisionCode) {
        this.divisionCode = divisionCode == null ? null : divisionCode.trim();
    }

    public String getDivisionName() {
        return divisionName;
    }

    public void setDivisionName(String divisionName) {
        this.divisionName = divisionName == null ? null : divisionName.trim();
    }

    public String getBusinessCenter() {
        return businessCenter;
    }

    public void setBusinessCenter(String businessCenter) {
        this.businessCenter = businessCenter == null ? null : businessCenter.trim();
    }

    public String getProductAttr() {
        return productAttr;
    }

    public void setProductAttr(String productAttr) {
        this.productAttr = productAttr == null ? null : productAttr.trim();
    }

    public String getFittingAttr() {
        return fittingAttr;
    }

    public void setFittingAttr(String fittingAttr) {
        this.fittingAttr = fittingAttr == null ? null : fittingAttr.trim();
    }

    public String getWarrantyProduct() {
        return warrantyProduct;
    }

    public void setWarrantyProduct(String warrantyProduct) {
        this.warrantyProduct = warrantyProduct == null ? null : warrantyProduct.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getIsRemoved() {
        return isRemoved;
    }

    public void setIsRemoved(String isRemoved) {
        this.isRemoved = isRemoved == null ? null : isRemoved.trim();
    }
}