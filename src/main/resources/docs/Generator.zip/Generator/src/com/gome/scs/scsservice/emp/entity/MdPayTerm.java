package com.gome.scs.scsservice.emp.entity;

import java.util.Date;

public class MdPayTerm {
    private Integer id;

    private String payTermCode;

    private String payTermName;

    private String subjectType;

    private Date updateTime;

    private String isRemoved;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPayTermCode() {
        return payTermCode;
    }

    public void setPayTermCode(String payTermCode) {
        this.payTermCode = payTermCode == null ? null : payTermCode.trim();
    }

    public String getPayTermName() {
        return payTermName;
    }

    public void setPayTermName(String payTermName) {
        this.payTermName = payTermName == null ? null : payTermName.trim();
    }

    public String getSubjectType() {
        return subjectType;
    }

    public void setSubjectType(String subjectType) {
        this.subjectType = subjectType == null ? null : subjectType.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getIsRemoved() {
        return isRemoved;
    }

    public void setIsRemoved(String isRemoved) {
        this.isRemoved = isRemoved == null ? null : isRemoved.trim();
    }
}