package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdSalesChannel;

public interface MdSalesChannelMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdSalesChannel record);

    int insertSelective(MdSalesChannel record);

    MdSalesChannel selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdSalesChannel record);

    int updateByPrimaryKey(MdSalesChannel record);
}