package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdCompany;

public interface MdCompanyMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdCompany record);

    int insertSelective(MdCompany record);

    MdCompany selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdCompany record);

    int updateByPrimaryKey(MdCompany record);
}