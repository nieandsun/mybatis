package com.gome.scs.scsservice.emp.entity;

import java.util.Date;

public class MdContract {
    private Integer id;

    private String documentType;

    private String contractCode;

    private String companyCode;

    private String buyorgCode;

    private String suppCode;

    private String classCode;

    private String classType;

    private String brandCode;

    private String payTermCode;

    private String payMethodCode;

    private String zhangqi;

    private String contractYear;

    private Date imageValidDate;

    private Date effectStartDate;

    private Date effectEndDate;

    private Date realEffectEndDate;

    private Date createTime;

    private String remark;

    private Date updateTime;

    private String updatePerson;

    private String isRemoved;

    private String sendScope;

    private String buyorggroupCode;

    private String singlePayGe;

    private String bankAcceptTime;

    private String exchangeFreight;

    private String imperfectionFreight;

    private String heelPriceFreight;

    private String signTaxDiscount;

    private String imperfectionFreightPercentage;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType == null ? null : documentType.trim();
    }

    public String getContractCode() {
        return contractCode;
    }

    public void setContractCode(String contractCode) {
        this.contractCode = contractCode == null ? null : contractCode.trim();
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode == null ? null : companyCode.trim();
    }

    public String getBuyorgCode() {
        return buyorgCode;
    }

    public void setBuyorgCode(String buyorgCode) {
        this.buyorgCode = buyorgCode == null ? null : buyorgCode.trim();
    }

    public String getSuppCode() {
        return suppCode;
    }

    public void setSuppCode(String suppCode) {
        this.suppCode = suppCode == null ? null : suppCode.trim();
    }

    public String getClassCode() {
        return classCode;
    }

    public void setClassCode(String classCode) {
        this.classCode = classCode == null ? null : classCode.trim();
    }

    public String getClassType() {
        return classType;
    }

    public void setClassType(String classType) {
        this.classType = classType == null ? null : classType.trim();
    }

    public String getBrandCode() {
        return brandCode;
    }

    public void setBrandCode(String brandCode) {
        this.brandCode = brandCode == null ? null : brandCode.trim();
    }

    public String getPayTermCode() {
        return payTermCode;
    }

    public void setPayTermCode(String payTermCode) {
        this.payTermCode = payTermCode == null ? null : payTermCode.trim();
    }

    public String getPayMethodCode() {
        return payMethodCode;
    }

    public void setPayMethodCode(String payMethodCode) {
        this.payMethodCode = payMethodCode == null ? null : payMethodCode.trim();
    }

    public String getZhangqi() {
        return zhangqi;
    }

    public void setZhangqi(String zhangqi) {
        this.zhangqi = zhangqi == null ? null : zhangqi.trim();
    }

    public String getContractYear() {
        return contractYear;
    }

    public void setContractYear(String contractYear) {
        this.contractYear = contractYear == null ? null : contractYear.trim();
    }

    public Date getImageValidDate() {
        return imageValidDate;
    }

    public void setImageValidDate(Date imageValidDate) {
        this.imageValidDate = imageValidDate;
    }

    public Date getEffectStartDate() {
        return effectStartDate;
    }

    public void setEffectStartDate(Date effectStartDate) {
        this.effectStartDate = effectStartDate;
    }

    public Date getEffectEndDate() {
        return effectEndDate;
    }

    public void setEffectEndDate(Date effectEndDate) {
        this.effectEndDate = effectEndDate;
    }

    public Date getRealEffectEndDate() {
        return realEffectEndDate;
    }

    public void setRealEffectEndDate(Date realEffectEndDate) {
        this.realEffectEndDate = realEffectEndDate;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdatePerson() {
        return updatePerson;
    }

    public void setUpdatePerson(String updatePerson) {
        this.updatePerson = updatePerson == null ? null : updatePerson.trim();
    }

    public String getIsRemoved() {
        return isRemoved;
    }

    public void setIsRemoved(String isRemoved) {
        this.isRemoved = isRemoved == null ? null : isRemoved.trim();
    }

    public String getSendScope() {
        return sendScope;
    }

    public void setSendScope(String sendScope) {
        this.sendScope = sendScope == null ? null : sendScope.trim();
    }

    public String getBuyorggroupCode() {
        return buyorggroupCode;
    }

    public void setBuyorggroupCode(String buyorggroupCode) {
        this.buyorggroupCode = buyorggroupCode == null ? null : buyorggroupCode.trim();
    }

    public String getSinglePayGe() {
        return singlePayGe;
    }

    public void setSinglePayGe(String singlePayGe) {
        this.singlePayGe = singlePayGe == null ? null : singlePayGe.trim();
    }

    public String getBankAcceptTime() {
        return bankAcceptTime;
    }

    public void setBankAcceptTime(String bankAcceptTime) {
        this.bankAcceptTime = bankAcceptTime == null ? null : bankAcceptTime.trim();
    }

    public String getExchangeFreight() {
        return exchangeFreight;
    }

    public void setExchangeFreight(String exchangeFreight) {
        this.exchangeFreight = exchangeFreight == null ? null : exchangeFreight.trim();
    }

    public String getImperfectionFreight() {
        return imperfectionFreight;
    }

    public void setImperfectionFreight(String imperfectionFreight) {
        this.imperfectionFreight = imperfectionFreight == null ? null : imperfectionFreight.trim();
    }

    public String getHeelPriceFreight() {
        return heelPriceFreight;
    }

    public void setHeelPriceFreight(String heelPriceFreight) {
        this.heelPriceFreight = heelPriceFreight == null ? null : heelPriceFreight.trim();
    }

    public String getSignTaxDiscount() {
        return signTaxDiscount;
    }

    public void setSignTaxDiscount(String signTaxDiscount) {
        this.signTaxDiscount = signTaxDiscount == null ? null : signTaxDiscount.trim();
    }

    public String getImperfectionFreightPercentage() {
        return imperfectionFreightPercentage;
    }

    public void setImperfectionFreightPercentage(String imperfectionFreightPercentage) {
        this.imperfectionFreightPercentage = imperfectionFreightPercentage == null ? null : imperfectionFreightPercentage.trim();
    }
}