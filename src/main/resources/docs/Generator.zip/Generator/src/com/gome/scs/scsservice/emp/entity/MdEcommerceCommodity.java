package com.gome.scs.scsservice.emp.entity;

import java.util.Date;

public class MdEcommerceCommodity {
    private Integer id;

    private String commodityCode;

    private String commodityName;

    private String commodityType;

    private String commodityCategory;

    private String brandCode;

    private String model;

    private String storeCode;

    private String unit;

    private String assessCode;

    private String manufacturer;

    private String originCountryCode;

    private String originProvinceCode;

    private String originDesc;

    private String weight;

    private String length;

    private String wide;

    private String high;

    private String upcCode;

    private String mrpType;

    private String orderPoint;

    private String secureStock;

    private String maxStock;

    private String predictionModelCode;

    private String periodCode;

    private String batchFlag;

    private String validityPeriod;

    private String stockoutWarn;

    private String unsalableWarn;

    private String priceControlCode;

    private String removedFlag;

    private String integral;

    private String mainParameter;

    private String minorParameter;

    private String lossFlag;

    private String installFlag;

    private String openExamine;

    private String gomeExclusive;

    private String invoice;

    private String freezeFlag;

    private String skyEmbargo;

    private String temperature;

    private String valuableFlag;

    private String dangerFlag;

    private String liquidFlag;

    private String privacyFlag;

    private String dispatchType;

    private String commodityGroup;

    private String taxType;

    private String conserveEnergyFlag;

    private String conserveEnergyPrice;

    private String bookPrice;

    private String bigCommodityFlag;

    private String cityCode;

    private String labelManage;

    private String importExportFlag;

    private String cardType;

    private String operator;

    private String districtCode;

    private String startNumber;

    private String endNumber;

    private Integer expirationDate;

    private String packSize;

    private String serialManage;

    private String goodsLifetime;

    private String eapplianceType;

    private String eapplianceCategory;

    private String eapplianceBrand;

    private String eapplianceTaxType;

    private Date commodityTime;

    private String updateFlag;

    private String ecommerceFlag;

    private String oaCode;

    private String applyBranch;

    private String applyPerson;

    private String makeType;

    private String unused;

    private String commodityStatus;

    private String warrantyUpperLimit;

    private String warrantyLowerLimit;

    private String skuId;

    private String codeLevel;

    private String sellingPoint;

    private String gifitFlag;

    private String batchSign;

    private String attribute;

    private String commodityShape;

    private String abcMark;

    private String isRemoved;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCommodityCode() {
        return commodityCode;
    }

    public void setCommodityCode(String commodityCode) {
        this.commodityCode = commodityCode == null ? null : commodityCode.trim();
    }

    public String getCommodityName() {
        return commodityName;
    }

    public void setCommodityName(String commodityName) {
        this.commodityName = commodityName == null ? null : commodityName.trim();
    }

    public String getCommodityType() {
        return commodityType;
    }

    public void setCommodityType(String commodityType) {
        this.commodityType = commodityType == null ? null : commodityType.trim();
    }

    public String getCommodityCategory() {
        return commodityCategory;
    }

    public void setCommodityCategory(String commodityCategory) {
        this.commodityCategory = commodityCategory == null ? null : commodityCategory.trim();
    }

    public String getBrandCode() {
        return brandCode;
    }

    public void setBrandCode(String brandCode) {
        this.brandCode = brandCode == null ? null : brandCode.trim();
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model == null ? null : model.trim();
    }

    public String getStoreCode() {
        return storeCode;
    }

    public void setStoreCode(String storeCode) {
        this.storeCode = storeCode == null ? null : storeCode.trim();
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit == null ? null : unit.trim();
    }

    public String getAssessCode() {
        return assessCode;
    }

    public void setAssessCode(String assessCode) {
        this.assessCode = assessCode == null ? null : assessCode.trim();
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer == null ? null : manufacturer.trim();
    }

    public String getOriginCountryCode() {
        return originCountryCode;
    }

    public void setOriginCountryCode(String originCountryCode) {
        this.originCountryCode = originCountryCode == null ? null : originCountryCode.trim();
    }

    public String getOriginProvinceCode() {
        return originProvinceCode;
    }

    public void setOriginProvinceCode(String originProvinceCode) {
        this.originProvinceCode = originProvinceCode == null ? null : originProvinceCode.trim();
    }

    public String getOriginDesc() {
        return originDesc;
    }

    public void setOriginDesc(String originDesc) {
        this.originDesc = originDesc == null ? null : originDesc.trim();
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight == null ? null : weight.trim();
    }

    public String getLength() {
        return length;
    }

    public void setLength(String length) {
        this.length = length == null ? null : length.trim();
    }

    public String getWide() {
        return wide;
    }

    public void setWide(String wide) {
        this.wide = wide == null ? null : wide.trim();
    }

    public String getHigh() {
        return high;
    }

    public void setHigh(String high) {
        this.high = high == null ? null : high.trim();
    }

    public String getUpcCode() {
        return upcCode;
    }

    public void setUpcCode(String upcCode) {
        this.upcCode = upcCode == null ? null : upcCode.trim();
    }

    public String getMrpType() {
        return mrpType;
    }

    public void setMrpType(String mrpType) {
        this.mrpType = mrpType == null ? null : mrpType.trim();
    }

    public String getOrderPoint() {
        return orderPoint;
    }

    public void setOrderPoint(String orderPoint) {
        this.orderPoint = orderPoint == null ? null : orderPoint.trim();
    }

    public String getSecureStock() {
        return secureStock;
    }

    public void setSecureStock(String secureStock) {
        this.secureStock = secureStock == null ? null : secureStock.trim();
    }

    public String getMaxStock() {
        return maxStock;
    }

    public void setMaxStock(String maxStock) {
        this.maxStock = maxStock == null ? null : maxStock.trim();
    }

    public String getPredictionModelCode() {
        return predictionModelCode;
    }

    public void setPredictionModelCode(String predictionModelCode) {
        this.predictionModelCode = predictionModelCode == null ? null : predictionModelCode.trim();
    }

    public String getPeriodCode() {
        return periodCode;
    }

    public void setPeriodCode(String periodCode) {
        this.periodCode = periodCode == null ? null : periodCode.trim();
    }

    public String getBatchFlag() {
        return batchFlag;
    }

    public void setBatchFlag(String batchFlag) {
        this.batchFlag = batchFlag == null ? null : batchFlag.trim();
    }

    public String getValidityPeriod() {
        return validityPeriod;
    }

    public void setValidityPeriod(String validityPeriod) {
        this.validityPeriod = validityPeriod == null ? null : validityPeriod.trim();
    }

    public String getStockoutWarn() {
        return stockoutWarn;
    }

    public void setStockoutWarn(String stockoutWarn) {
        this.stockoutWarn = stockoutWarn == null ? null : stockoutWarn.trim();
    }

    public String getUnsalableWarn() {
        return unsalableWarn;
    }

    public void setUnsalableWarn(String unsalableWarn) {
        this.unsalableWarn = unsalableWarn == null ? null : unsalableWarn.trim();
    }

    public String getPriceControlCode() {
        return priceControlCode;
    }

    public void setPriceControlCode(String priceControlCode) {
        this.priceControlCode = priceControlCode == null ? null : priceControlCode.trim();
    }

    public String getRemovedFlag() {
        return removedFlag;
    }

    public void setRemovedFlag(String removedFlag) {
        this.removedFlag = removedFlag == null ? null : removedFlag.trim();
    }

    public String getIntegral() {
        return integral;
    }

    public void setIntegral(String integral) {
        this.integral = integral == null ? null : integral.trim();
    }

    public String getMainParameter() {
        return mainParameter;
    }

    public void setMainParameter(String mainParameter) {
        this.mainParameter = mainParameter == null ? null : mainParameter.trim();
    }

    public String getMinorParameter() {
        return minorParameter;
    }

    public void setMinorParameter(String minorParameter) {
        this.minorParameter = minorParameter == null ? null : minorParameter.trim();
    }

    public String getLossFlag() {
        return lossFlag;
    }

    public void setLossFlag(String lossFlag) {
        this.lossFlag = lossFlag == null ? null : lossFlag.trim();
    }

    public String getInstallFlag() {
        return installFlag;
    }

    public void setInstallFlag(String installFlag) {
        this.installFlag = installFlag == null ? null : installFlag.trim();
    }

    public String getOpenExamine() {
        return openExamine;
    }

    public void setOpenExamine(String openExamine) {
        this.openExamine = openExamine == null ? null : openExamine.trim();
    }

    public String getGomeExclusive() {
        return gomeExclusive;
    }

    public void setGomeExclusive(String gomeExclusive) {
        this.gomeExclusive = gomeExclusive == null ? null : gomeExclusive.trim();
    }

    public String getInvoice() {
        return invoice;
    }

    public void setInvoice(String invoice) {
        this.invoice = invoice == null ? null : invoice.trim();
    }

    public String getFreezeFlag() {
        return freezeFlag;
    }

    public void setFreezeFlag(String freezeFlag) {
        this.freezeFlag = freezeFlag == null ? null : freezeFlag.trim();
    }

    public String getSkyEmbargo() {
        return skyEmbargo;
    }

    public void setSkyEmbargo(String skyEmbargo) {
        this.skyEmbargo = skyEmbargo == null ? null : skyEmbargo.trim();
    }

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature == null ? null : temperature.trim();
    }

    public String getValuableFlag() {
        return valuableFlag;
    }

    public void setValuableFlag(String valuableFlag) {
        this.valuableFlag = valuableFlag == null ? null : valuableFlag.trim();
    }

    public String getDangerFlag() {
        return dangerFlag;
    }

    public void setDangerFlag(String dangerFlag) {
        this.dangerFlag = dangerFlag == null ? null : dangerFlag.trim();
    }

    public String getLiquidFlag() {
        return liquidFlag;
    }

    public void setLiquidFlag(String liquidFlag) {
        this.liquidFlag = liquidFlag == null ? null : liquidFlag.trim();
    }

    public String getPrivacyFlag() {
        return privacyFlag;
    }

    public void setPrivacyFlag(String privacyFlag) {
        this.privacyFlag = privacyFlag == null ? null : privacyFlag.trim();
    }

    public String getDispatchType() {
        return dispatchType;
    }

    public void setDispatchType(String dispatchType) {
        this.dispatchType = dispatchType == null ? null : dispatchType.trim();
    }

    public String getCommodityGroup() {
        return commodityGroup;
    }

    public void setCommodityGroup(String commodityGroup) {
        this.commodityGroup = commodityGroup == null ? null : commodityGroup.trim();
    }

    public String getTaxType() {
        return taxType;
    }

    public void setTaxType(String taxType) {
        this.taxType = taxType == null ? null : taxType.trim();
    }

    public String getConserveEnergyFlag() {
        return conserveEnergyFlag;
    }

    public void setConserveEnergyFlag(String conserveEnergyFlag) {
        this.conserveEnergyFlag = conserveEnergyFlag == null ? null : conserveEnergyFlag.trim();
    }

    public String getConserveEnergyPrice() {
        return conserveEnergyPrice;
    }

    public void setConserveEnergyPrice(String conserveEnergyPrice) {
        this.conserveEnergyPrice = conserveEnergyPrice == null ? null : conserveEnergyPrice.trim();
    }

    public String getBookPrice() {
        return bookPrice;
    }

    public void setBookPrice(String bookPrice) {
        this.bookPrice = bookPrice == null ? null : bookPrice.trim();
    }

    public String getBigCommodityFlag() {
        return bigCommodityFlag;
    }

    public void setBigCommodityFlag(String bigCommodityFlag) {
        this.bigCommodityFlag = bigCommodityFlag == null ? null : bigCommodityFlag.trim();
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode == null ? null : cityCode.trim();
    }

    public String getLabelManage() {
        return labelManage;
    }

    public void setLabelManage(String labelManage) {
        this.labelManage = labelManage == null ? null : labelManage.trim();
    }

    public String getImportExportFlag() {
        return importExportFlag;
    }

    public void setImportExportFlag(String importExportFlag) {
        this.importExportFlag = importExportFlag == null ? null : importExportFlag.trim();
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType == null ? null : cardType.trim();
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator == null ? null : operator.trim();
    }

    public String getDistrictCode() {
        return districtCode;
    }

    public void setDistrictCode(String districtCode) {
        this.districtCode = districtCode == null ? null : districtCode.trim();
    }

    public String getStartNumber() {
        return startNumber;
    }

    public void setStartNumber(String startNumber) {
        this.startNumber = startNumber == null ? null : startNumber.trim();
    }

    public String getEndNumber() {
        return endNumber;
    }

    public void setEndNumber(String endNumber) {
        this.endNumber = endNumber == null ? null : endNumber.trim();
    }

    public Integer getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(Integer expirationDate) {
        this.expirationDate = expirationDate;
    }

    public String getPackSize() {
        return packSize;
    }

    public void setPackSize(String packSize) {
        this.packSize = packSize == null ? null : packSize.trim();
    }

    public String getSerialManage() {
        return serialManage;
    }

    public void setSerialManage(String serialManage) {
        this.serialManage = serialManage == null ? null : serialManage.trim();
    }

    public String getGoodsLifetime() {
        return goodsLifetime;
    }

    public void setGoodsLifetime(String goodsLifetime) {
        this.goodsLifetime = goodsLifetime == null ? null : goodsLifetime.trim();
    }

    public String getEapplianceType() {
        return eapplianceType;
    }

    public void setEapplianceType(String eapplianceType) {
        this.eapplianceType = eapplianceType == null ? null : eapplianceType.trim();
    }

    public String getEapplianceCategory() {
        return eapplianceCategory;
    }

    public void setEapplianceCategory(String eapplianceCategory) {
        this.eapplianceCategory = eapplianceCategory == null ? null : eapplianceCategory.trim();
    }

    public String getEapplianceBrand() {
        return eapplianceBrand;
    }

    public void setEapplianceBrand(String eapplianceBrand) {
        this.eapplianceBrand = eapplianceBrand == null ? null : eapplianceBrand.trim();
    }

    public String getEapplianceTaxType() {
        return eapplianceTaxType;
    }

    public void setEapplianceTaxType(String eapplianceTaxType) {
        this.eapplianceTaxType = eapplianceTaxType == null ? null : eapplianceTaxType.trim();
    }

    public Date getCommodityTime() {
        return commodityTime;
    }

    public void setCommodityTime(Date commodityTime) {
        this.commodityTime = commodityTime;
    }

    public String getUpdateFlag() {
        return updateFlag;
    }

    public void setUpdateFlag(String updateFlag) {
        this.updateFlag = updateFlag == null ? null : updateFlag.trim();
    }

    public String getEcommerceFlag() {
        return ecommerceFlag;
    }

    public void setEcommerceFlag(String ecommerceFlag) {
        this.ecommerceFlag = ecommerceFlag == null ? null : ecommerceFlag.trim();
    }

    public String getOaCode() {
        return oaCode;
    }

    public void setOaCode(String oaCode) {
        this.oaCode = oaCode == null ? null : oaCode.trim();
    }

    public String getApplyBranch() {
        return applyBranch;
    }

    public void setApplyBranch(String applyBranch) {
        this.applyBranch = applyBranch == null ? null : applyBranch.trim();
    }

    public String getApplyPerson() {
        return applyPerson;
    }

    public void setApplyPerson(String applyPerson) {
        this.applyPerson = applyPerson == null ? null : applyPerson.trim();
    }

    public String getMakeType() {
        return makeType;
    }

    public void setMakeType(String makeType) {
        this.makeType = makeType == null ? null : makeType.trim();
    }

    public String getUnused() {
        return unused;
    }

    public void setUnused(String unused) {
        this.unused = unused == null ? null : unused.trim();
    }

    public String getCommodityStatus() {
        return commodityStatus;
    }

    public void setCommodityStatus(String commodityStatus) {
        this.commodityStatus = commodityStatus == null ? null : commodityStatus.trim();
    }

    public String getWarrantyUpperLimit() {
        return warrantyUpperLimit;
    }

    public void setWarrantyUpperLimit(String warrantyUpperLimit) {
        this.warrantyUpperLimit = warrantyUpperLimit == null ? null : warrantyUpperLimit.trim();
    }

    public String getWarrantyLowerLimit() {
        return warrantyLowerLimit;
    }

    public void setWarrantyLowerLimit(String warrantyLowerLimit) {
        this.warrantyLowerLimit = warrantyLowerLimit == null ? null : warrantyLowerLimit.trim();
    }

    public String getSkuId() {
        return skuId;
    }

    public void setSkuId(String skuId) {
        this.skuId = skuId == null ? null : skuId.trim();
    }

    public String getCodeLevel() {
        return codeLevel;
    }

    public void setCodeLevel(String codeLevel) {
        this.codeLevel = codeLevel == null ? null : codeLevel.trim();
    }

    public String getSellingPoint() {
        return sellingPoint;
    }

    public void setSellingPoint(String sellingPoint) {
        this.sellingPoint = sellingPoint == null ? null : sellingPoint.trim();
    }

    public String getGifitFlag() {
        return gifitFlag;
    }

    public void setGifitFlag(String gifitFlag) {
        this.gifitFlag = gifitFlag == null ? null : gifitFlag.trim();
    }

    public String getBatchSign() {
        return batchSign;
    }

    public void setBatchSign(String batchSign) {
        this.batchSign = batchSign == null ? null : batchSign.trim();
    }

    public String getAttribute() {
        return attribute;
    }

    public void setAttribute(String attribute) {
        this.attribute = attribute == null ? null : attribute.trim();
    }

    public String getCommodityShape() {
        return commodityShape;
    }

    public void setCommodityShape(String commodityShape) {
        this.commodityShape = commodityShape == null ? null : commodityShape.trim();
    }

    public String getAbcMark() {
        return abcMark;
    }

    public void setAbcMark(String abcMark) {
        this.abcMark = abcMark == null ? null : abcMark.trim();
    }

    public String getIsRemoved() {
        return isRemoved;
    }

    public void setIsRemoved(String isRemoved) {
        this.isRemoved = isRemoved == null ? null : isRemoved.trim();
    }
}