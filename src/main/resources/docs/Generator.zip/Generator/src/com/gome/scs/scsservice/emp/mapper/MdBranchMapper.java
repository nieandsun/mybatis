package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdBranch;

public interface MdBranchMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdBranch record);

    int insertSelective(MdBranch record);

    MdBranch selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdBranch record);

    int updateByPrimaryKey(MdBranch record);
}