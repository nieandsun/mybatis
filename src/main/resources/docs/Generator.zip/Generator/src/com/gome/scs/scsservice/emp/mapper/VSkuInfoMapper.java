package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.VSkuInfo;

public interface VSkuInfoMapper {
    int insert(VSkuInfo record);

    int insertSelective(VSkuInfo record);
}