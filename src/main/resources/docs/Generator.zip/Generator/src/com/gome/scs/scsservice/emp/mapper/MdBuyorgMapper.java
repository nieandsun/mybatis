package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdBuyorg;

public interface MdBuyorgMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdBuyorg record);

    int insertSelective(MdBuyorg record);

    MdBuyorg selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdBuyorg record);

    int updateByPrimaryKey(MdBuyorg record);
}