package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.TSysconfigGomeMain;

public interface TSysconfigGomeMainMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(TSysconfigGomeMain record);

    int insertSelective(TSysconfigGomeMain record);

    TSysconfigGomeMain selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(TSysconfigGomeMain record);

    int updateByPrimaryKey(TSysconfigGomeMain record);
}