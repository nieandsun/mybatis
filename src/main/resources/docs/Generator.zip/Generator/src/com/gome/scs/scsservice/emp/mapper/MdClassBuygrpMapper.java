package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdClassBuygrp;

public interface MdClassBuygrpMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdClassBuygrp record);

    int insertSelective(MdClassBuygrp record);

    MdClassBuygrp selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdClassBuygrp record);

    int updateByPrimaryKey(MdClassBuygrp record);
}