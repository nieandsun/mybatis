package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdClassCopy;

public interface MdClassCopyMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdClassCopy record);

    int insertSelective(MdClassCopy record);

    MdClassCopy selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdClassCopy record);

    int updateByPrimaryKey(MdClassCopy record);
}