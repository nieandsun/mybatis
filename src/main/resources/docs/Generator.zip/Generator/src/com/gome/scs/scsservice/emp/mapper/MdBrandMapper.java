package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdBrand;

public interface MdBrandMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdBrand record);

    int insertSelective(MdBrand record);

    MdBrand selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdBrand record);

    int updateByPrimaryKey(MdBrand record);
}