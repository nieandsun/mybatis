package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.ScsContractCode;

public interface ScsContractCodeMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(ScsContractCode record);

    int insertSelective(ScsContractCode record);

    ScsContractCode selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(ScsContractCode record);

    int updateByPrimaryKey(ScsContractCode record);
}