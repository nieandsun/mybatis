package com.gome.scs.scsservice.emp.entity;

public class MdSaleGrp {
    private Integer id;

    private String saleGrpCode;

    private String saleGrpName;

    private String saleGrpLevel;

    private String isRemoved;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSaleGrpCode() {
        return saleGrpCode;
    }

    public void setSaleGrpCode(String saleGrpCode) {
        this.saleGrpCode = saleGrpCode == null ? null : saleGrpCode.trim();
    }

    public String getSaleGrpName() {
        return saleGrpName;
    }

    public void setSaleGrpName(String saleGrpName) {
        this.saleGrpName = saleGrpName == null ? null : saleGrpName.trim();
    }

    public String getSaleGrpLevel() {
        return saleGrpLevel;
    }

    public void setSaleGrpLevel(String saleGrpLevel) {
        this.saleGrpLevel = saleGrpLevel == null ? null : saleGrpLevel.trim();
    }

    public String getIsRemoved() {
        return isRemoved;
    }

    public void setIsRemoved(String isRemoved) {
        this.isRemoved = isRemoved == null ? null : isRemoved.trim();
    }
}