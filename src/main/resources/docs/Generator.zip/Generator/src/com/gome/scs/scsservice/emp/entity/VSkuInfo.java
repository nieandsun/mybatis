package com.gome.scs.scsservice.emp.entity;

public class VSkuInfo {
    private String skuNo;

    private String skuName;

    private String category1Code;

    private String category1Name;

    private String categoryCode;

    private String categoryName;

    private String category3Code;

    private String category3Name;

    private String category4Code;

    private String category4Name;

    private String brandCode;

    private String brandName;

    public String getSkuNo() {
        return skuNo;
    }

    public void setSkuNo(String skuNo) {
        this.skuNo = skuNo == null ? null : skuNo.trim();
    }

    public String getSkuName() {
        return skuName;
    }

    public void setSkuName(String skuName) {
        this.skuName = skuName == null ? null : skuName.trim();
    }

    public String getCategory1Code() {
        return category1Code;
    }

    public void setCategory1Code(String category1Code) {
        this.category1Code = category1Code == null ? null : category1Code.trim();
    }

    public String getCategory1Name() {
        return category1Name;
    }

    public void setCategory1Name(String category1Name) {
        this.category1Name = category1Name == null ? null : category1Name.trim();
    }

    public String getCategoryCode() {
        return categoryCode;
    }

    public void setCategoryCode(String categoryCode) {
        this.categoryCode = categoryCode == null ? null : categoryCode.trim();
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName == null ? null : categoryName.trim();
    }

    public String getCategory3Code() {
        return category3Code;
    }

    public void setCategory3Code(String category3Code) {
        this.category3Code = category3Code == null ? null : category3Code.trim();
    }

    public String getCategory3Name() {
        return category3Name;
    }

    public void setCategory3Name(String category3Name) {
        this.category3Name = category3Name == null ? null : category3Name.trim();
    }

    public String getCategory4Code() {
        return category4Code;
    }

    public void setCategory4Code(String category4Code) {
        this.category4Code = category4Code == null ? null : category4Code.trim();
    }

    public String getCategory4Name() {
        return category4Name;
    }

    public void setCategory4Name(String category4Name) {
        this.category4Name = category4Name == null ? null : category4Name.trim();
    }

    public String getBrandCode() {
        return brandCode;
    }

    public void setBrandCode(String brandCode) {
        this.brandCode = brandCode == null ? null : brandCode.trim();
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName == null ? null : brandName.trim();
    }
}