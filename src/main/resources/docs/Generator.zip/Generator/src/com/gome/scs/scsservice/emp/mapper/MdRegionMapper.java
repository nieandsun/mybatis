package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdRegion;

public interface MdRegionMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdRegion record);

    int insertSelective(MdRegion record);

    MdRegion selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdRegion record);

    int updateByPrimaryKey(MdRegion record);
}