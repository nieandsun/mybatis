package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdContractComputedPolicy;

public interface MdContractComputedPolicyMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdContractComputedPolicy record);

    int insertSelective(MdContractComputedPolicy record);

    MdContractComputedPolicy selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdContractComputedPolicy record);

    int updateByPrimaryKey(MdContractComputedPolicy record);
}