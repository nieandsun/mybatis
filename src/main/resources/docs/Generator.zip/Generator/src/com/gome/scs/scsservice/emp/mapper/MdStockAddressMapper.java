package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.MdStockAddress;

public interface MdStockAddressMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MdStockAddress record);

    int insertSelective(MdStockAddress record);

    MdStockAddress selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MdStockAddress record);

    int updateByPrimaryKey(MdStockAddress record);
}