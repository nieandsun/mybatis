package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.ScsOaAuditRemark;

public interface ScsOaAuditRemarkMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(ScsOaAuditRemark record);

    int insertSelective(ScsOaAuditRemark record);

    ScsOaAuditRemark selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(ScsOaAuditRemark record);

    int updateByPrimaryKey(ScsOaAuditRemark record);
}