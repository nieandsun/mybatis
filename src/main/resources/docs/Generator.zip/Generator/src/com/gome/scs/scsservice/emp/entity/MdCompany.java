package com.gome.scs.scsservice.emp.entity;

import java.util.Date;

public class MdCompany {
    private Integer id;

    private String companyCode;

    private String companyName;

    private String companyRegisteAddress;

    private Date updateTime;

    private String isRemoved;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode == null ? null : companyCode.trim();
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName == null ? null : companyName.trim();
    }

    public String getCompanyRegisteAddress() {
        return companyRegisteAddress;
    }

    public void setCompanyRegisteAddress(String companyRegisteAddress) {
        this.companyRegisteAddress = companyRegisteAddress == null ? null : companyRegisteAddress.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getIsRemoved() {
        return isRemoved;
    }

    public void setIsRemoved(String isRemoved) {
        this.isRemoved = isRemoved == null ? null : isRemoved.trim();
    }
}