package com.gome.scs.scsservice.emp.mapper;

import com.gome.scs.scsservice.emp.entity.TAcGomeUserpostlog;

public interface TAcGomeUserpostlogMapper {
    int deleteByPrimaryKey(Long id);

    int insert(TAcGomeUserpostlog record);

    int insertSelective(TAcGomeUserpostlog record);

    TAcGomeUserpostlog selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TAcGomeUserpostlog record);

    int updateByPrimaryKey(TAcGomeUserpostlog record);
}